#!/bin/bash

pip install pytelegrambotapi python-dotenv pycryptodome
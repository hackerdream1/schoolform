# 版权所有 (C) 2025 Muttix 保留所有权利
# 项目名称: UU_Search_TGBot (Telegram文件代码搜索器机器人)
# 文件名称: main.py
# Email: sunmutian88@gmail.com

# 引入库
import os
import telebot
import json
import gzip
import base64
import datetime
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
from dotenv import load_dotenv
from telebot.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove, InlineKeyboardMarkup, InlineKeyboardButton

# 函数区
# 将毫秒级时间戳转换为datetime对象
def timestamp_to_datetime(timestamp_ms):
    # 将毫秒转换为秒
    timestamp_sec = timestamp_ms / 1000.0
    return datetime.datetime.fromtimestamp(timestamp_sec)

# 获取当前时间戳（字符串格式）
def get_current_time():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# 全局变量 - 日志文件路径
LOG_FILEPATH = None

# 初始化日志系统
def init_log_system():
    global LOG_FILEPATH
    try:
        # 确保log目录存在
        log_dir = "./log"
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        
        # 创建日志文件名（使用启动时间戳）
        startup_time = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        log_filename = f"LOG_{startup_time}.log"
        LOG_FILEPATH = os.path.join(log_dir, log_filename)
        
        # 创建日志文件并写入启动信息
        with open(LOG_FILEPATH, "w", encoding="utf-8") as f:
            f.write(f"=== UU Search Bot 启动于 {get_current_time()} ===\n\n")
        
        print(f"[{get_current_time()}] [INIT] 日志系统初始化完成: {LOG_FILEPATH}")
        return True
        
    except Exception as e:
        print(f"[{get_current_time()}] [ERROR] 初始化日志系统失败: {e}")
        return False

# 日志记录函数
def log_message(message, log_type="INFO"):
    timestamp = get_current_time()
    log_entry = f"[{timestamp}] [{log_type}] {message}"
    
    # 打印到控制台
    print(log_entry)
    
    # 写入日志文件
    if LOG_FILEPATH:
        try:
            with open(LOG_FILEPATH, "a", encoding="utf-8") as f:
                f.write(log_entry + "\n")
        except Exception as e:
            print(f"[{get_current_time()}] [ERROR] 写入日志文件失败: {e}")

# 读取文本文件
def read_text_file(filepath):
    try:
        if os.path.exists(filepath):
            with open(filepath, "r", encoding="utf-8") as f:
                return f.read().strip()
        else:
            log_message(f"文件不存在: {filepath}", "ERROR")
            return None
    except Exception as e:
        log_message(f"读取文件失败 {filepath}: {e}", "ERROR")
        return None

# 搜索函数
def search_in_descriptions(database, keyword):
    # 在代码介绍中搜索关键词
    if not database or "db_data" not in database:
        return []
    
    results = []
    for item in database["db_data"]:
        if len(item) >= 3:  # 确保有代码介绍字段
            code, code_type, description = item
            if keyword.lower() in description.lower():
                results.append(item)
    
    return results

# 获取用户显示名称
def get_user_display_name(user):
    # 如果有 first_name 和 last_name
    if user.first_name and user.last_name:
        return f"{user.first_name} {user.last_name}"
    # 如果只有 first_name
    elif user.first_name:
        return user.first_name
    # 如果只有 last_name（这种情况很少见）
    elif user.last_name:
        return user.last_name
    # 如果有 username
    elif user.username:
        return f"@{user.username}"
    # 如果什么都没有，使用用户ID
    else:
        return f"用户{user.id}"
    
# Telegram机器人主类
class TelegramBot:
    # 从文件加载欢迎消息
    def load_welcome_message(self):
        content = read_text_file(self.WELCOME_MESSAGE_PATH)
        if content:
            log_message(f"已加载欢迎消息，长度: {len(content)} 字符", "INFO")
            return content
        else:
            log_message("欢迎消息文件不存在或读取失败", "ERROR")
            return "欢迎消息加载失败，请联系管理员。"

    # 从文件加载用户协议
    def load_user_agreement(self):
        content = read_text_file(self.USER_AGREEMENT_PATH)
        if content:
            log_message(f"已加载用户协议，长度: {len(content)} 字符", "INFO")
            return content
        else:
            log_message("用户协议文件不存在或读取失败", "ERROR")
            return "用户协议加载失败，请联系管理员。"

    # 从文件加载帮助信息
    def load_help_message(self):
        content = read_text_file(self.HELP_MESSAGE_PATH)
        if content:
            log_message(f"已加载帮助信息，长度: {len(content)} 字符", "INFO")
            return content
        else:
            log_message("帮助信息文件不存在或读取失败", "ERROR")
            return "帮助信息加载失败，请联系管理员。"
    # 初始化机器人配置
    def __init__(self):
        # 初始化日志系统
        if not init_log_system():
            print("日志系统初始化失败，程序退出")
            exit(1)
            
        # 加载.env文件中的环境变量
        load_dotenv()
        # 从环境变量获取机器人Token
        self.BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
        # 从环境变量获取文件路径
        self.WELCOME_MESSAGE_PATH = os.getenv("WELCOME_MESSAGE_PATH", "./data/welcome_message.txt")
        self.USER_AGREEMENT_PATH = os.getenv("USER_AGREEMENT_PATH", "./data/user_agreement.txt")
        self.HELP_MESSAGE_PATH = os.getenv("HELP_MESSAGE_PATH", "./data/help_message.txt")
        self.DEFAULT_DATABASE_PATH = os.getenv("DEFAULT_DATABASE_PATH")
        # 管理员ID列表
        self.ADMIN_IDS = [int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip()]
        
        # LOG
        log_message(f"TELEGRAM_BOT_TOKEN = {self.BOT_TOKEN}", "ENV")
        log_message(f"WELCOME_MESSAGE_PATH = {self.WELCOME_MESSAGE_PATH}", "ENV")
        log_message(f"USER_AGREEMENT_PATH = {self.USER_AGREEMENT_PATH}", "ENV")
        log_message(f"HELP_MESSAGE_PATH = {self.HELP_MESSAGE_PATH}", "ENV")
        log_message(f"DEFAULT_DATABASE_PATH = {self.DEFAULT_DATABASE_PATH}", "ENV")
        log_message(f"ADMIN_IDS = {self.ADMIN_IDS}", "ENV")
        
        # 初始化机器人实例
        self.bot = None
        # 初始化数据库
        self.o_database = None
        # 用户搜索状态存储
        self.user_search_sessions = {}
        # VIP用户数据
        self.vip_users = {}
        # 用户搜索次数记录
        self.user_search_counts = {}
        
        # 加载VIP用户数据
        self.load_vip_users()
        # 加载用户搜索次数
        self.load_user_search_counts()
        
        # 从文件读取欢迎消息
        self.WelcomeMessage = "欢迎消息加载失败，请联系管理员。"
        # 从文件读取用户协议
        self.UserAgreement = "用户协议加载失败，请联系管理员。"
        # 从文件读取帮助信息
        self.HelpMessage = "帮助信息加载失败，请联系管理员。"

        # 实际加载消息内容
        self.WelcomeMessage = self.load_welcome_message()
        self.UserAgreement = self.load_user_agreement()
        self.HelpMessage = self.load_help_message()

    # 加载VIP用户数据
    def load_vip_users(self):
        try:
            if os.path.exists("vip_users.json"):
                with open("vip_users.json", "r", encoding="utf-8") as f:
                    self.vip_users = json.load(f)
                log_message(f"已加载 {len(self.vip_users)} 个VIP用户", "INFO")
        except Exception as e:
            log_message(f"加载VIP用户数据失败: {e}", "ERROR")
            self.vip_users = {}

    # 保存VIP用户数据
    def save_vip_users(self):
        try:
            with open("vip_users.json", "w", encoding="utf-8") as f:
                json.dump(self.vip_users, f, ensure_ascii=False, indent=2)
        except Exception as e:
            log_message(f"保存VIP用户数据失败: {e}", "ERROR")

    # 加载用户搜索次数
    def load_user_search_counts(self):
        try:
            if os.path.exists("user_search_counts.json"):
                with open("user_search_counts.json", "r", encoding="utf-8") as f:
                    data = json.load(f)
                    # 检查日期，如果是新的一天则重置计数
                    current_date = datetime.datetime.now().strftime("%Y-%m-%d")
                    if data.get('date') != current_date:
                        self.user_search_counts = {}
                    else:
                        self.user_search_counts = data.get('counts', {})
        except Exception as e:
            log_message(f"加载用户搜索次数失败: {e}", "ERROR")
            self.user_search_counts = {}

    # 保存用户搜索次数
    def save_user_search_counts(self):
        try:
            current_date = datetime.datetime.now().strftime("%Y-%m-%d")
            data = {
                'date': current_date,
                'counts': self.user_search_counts
            }
            with open("user_search_counts.json", "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            log_message(f"保存用户搜索次数失败: {e}", "ERROR")

    # 检查用户VIP状态
    def is_vip_user(self, user_id):
        # 管理员自动拥有VIP权限（无限制）
        if user_id in self.ADMIN_IDS:
            return True
        
        user_id_str = str(user_id)
        if user_id_str in self.vip_users:
            expiry_time = datetime.datetime.fromisoformat(self.vip_users[user_id_str]['expiry_time'])
            if expiry_time > datetime.datetime.now():
                return True
            else:
                # VIP已过期，删除记录
                del self.vip_users[user_id_str]
                self.save_vip_users()
        return False

    # 获取VIP剩余时间
    def get_vip_remaining_time(self, user_id):
        # 管理员显示无限制
        if user_id in self.ADMIN_IDS:
            return "永久"
        
        user_id_str = str(user_id)
        if user_id_str in self.vip_users:
            expiry_time = datetime.datetime.fromisoformat(self.vip_users[user_id_str]['expiry_time'])
            remaining = expiry_time - datetime.datetime.now()
            if remaining.total_seconds() > 0:
                days = remaining.days
                hours = remaining.seconds // 3600
                return f"{days}天{hours}小时"
        return "无"

    # 检查用户搜索限制
    def check_search_limit(self, user_id):
        if self.is_vip_user(user_id):
            return True, None  # VIP用户无限制
        
        user_id_str = str(user_id)
        today_searches = self.user_search_counts.get(user_id_str, 0)
        
        if today_searches >= 10:  # 非VIP用户每天最多10次搜索
            return False, "❌ 今日搜索次数已达上限（10次）\n\n⭐ 升级VIP可享受无限制搜索！"
        
        # 更新搜索次数
        self.user_search_counts[user_id_str] = today_searches + 1
        self.save_user_search_counts()
        
        remaining_searches = 10 - (today_searches + 1)
        if remaining_searches <= 3:
            return True, f"💡 今日剩余搜索次数：{remaining_searches}次\n⭐ 升级VIP享受无限制搜索！"
        
        return True, None

    # 添加VIP用户
    def add_vip_user(self, user_id, days=30):
        user_id_str = str(user_id)
        expiry_time = datetime.datetime.now() + datetime.timedelta(days=days)
        self.vip_users[user_id_str] = {
            'expiry_time': expiry_time.isoformat(),
            'added_time': datetime.datetime.now().isoformat(),
            'days': days
        }
        self.save_vip_users()
        log_message(f"用户 {user_id} 已添加VIP，有效期{days}天", "VIP")

    # 检查翻页限制（非VIP用户最多6页）
    def check_page_limit(self, user_id, page_number):
        if self.is_vip_user(user_id):
            return True  # VIP用户无限制
        
        if page_number > 6:  # 非VIP用户最多查看6页
            return False
        
        return True

    # 创建主菜单底部键盘
    def create_main_keyboard(self):
        # 创建主菜单底部键盘
        markup = ReplyKeyboardMarkup(
            resize_keyboard=True,
            one_time_keyboard=False
        )
        
        # 根据VIP状态显示不同按钮
        markup.row("📜 使用协议", "ℹ️ 帮助信息")
        markup.row("👤 我的信息", "⭐ VIP服务")
        
        return markup

    # 创建VIP服务键盘
    def create_vip_keyboard(self):
        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("💰 购买VIP", callback_data="vip_buy"),
            InlineKeyboardButton("📊 VIP状态", callback_data="vip_status")
        )
        markup.row(InlineKeyboardButton("🏠 返回主页", callback_data="back_to_main"))
        return markup

    # 创建分页内联键盘（带跳转功能）
    def create_pagination_keyboard(self, current_page, total_pages, search_id):
        # 创建分页内联键盘
        markup = InlineKeyboardMarkup()
        
        # 页码信息
        page_info = f"{current_page}/{total_pages}"
        
        # 翻页按钮
        row_buttons = []
        if current_page > 1:
            row_buttons.append(InlineKeyboardButton("⬅️ 上一页", callback_data=f"page_{search_id}_{current_page-1}"))
        
        row_buttons.append(InlineKeyboardButton(f"📄 {page_info}", callback_data="page_info"))
        
        if current_page < total_pages:
            row_buttons.append(InlineKeyboardButton("下一页 ➡️", callback_data=f"page_{search_id}_{current_page+1}"))
        
        markup.row(*row_buttons)
        
        # 跳转页面按钮（仅VIP用户显示）
        if self.check_page_limit(999999, current_page + 1):  # 临时检查
            markup.row(InlineKeyboardButton("🔢 跳转到页面", callback_data=f"jump_{search_id}"))
        
        # 操作按钮
        markup.row(
            InlineKeyboardButton("🔄 重新搜索", callback_data="new_search"),
            InlineKeyboardButton("🏠 返回主页", callback_data="back_to_main")
        )
        
        return markup

    # 创建管理员键盘
    def create_admin_keyboard(self):
        markup = ReplyKeyboardMarkup(resize_keyboard=True)
        markup.row("📊 统计信息", "👥 用户管理")
        markup.row("⭐ VIP管理", "🔄 重置限制")
        markup.row("🏠 返回主菜单")
        return markup

    # 移除键盘
    def remove_keyboard(self):
        # 移除键盘
        return ReplyKeyboardRemove()

    # 获取数据库信息
    def get_database_info(self):
        # 获取数据库信息用于显示
        if not self.o_database:
            return "❌ 数据库未加载"
        
        db_name = self.o_database.get('name', '未知数据库')
        db_time = self.o_database.get('time', 0)
        db_notes = self.o_database.get('notes', '无备注')
        data_count = len(self.o_database.get('db_data', []))
        
        # 格式化时间
        if db_time:
            formatted_time = timestamp_to_datetime(db_time).strftime('%Y-%m-%d %H:%M:%S')
        else:
            formatted_time = '未知时间'
        
        info = f"""
<b>📊 数据库信息</b>

📁 数据库名称: {db_name}
📅 创建时间: {formatted_time}
📝 数据库备注: {db_notes}
📋 数据条目: {data_count} 条
"""
        return info

    # 初始化代码数据库
    def initDataBase(self):
        # 数据库文件格式:
        # 代码种类: 1: FilesDriveBLGA与旧密文
        #          2: MediaBKbot
        #          3: showfilesbot
        #          4: DataPanBot
        #          5: FilesPan1Bot
        #          6: 南天门解码器 (@ntmjmqbot)
        # {
        #     name:"数据库名称",
        #     time:"数据库日期",
        #     notes:"数据库注释",
        #     db_data:[
        #         [代码,代码种类,代码介绍],
        #         [代码,代码种类,代码介绍],
        #         [代码,代码种类,代码介绍],
        #         ...
        #     ]
        # }
        
        try:
            # 读取数据库文件
            with gzip.open(self.DEFAULT_DATABASE_PATH, 'rb') as f:
                final_encrypted_base64 = f.read()
            # 第一步：base64解码
            encrypted_data = base64.b64decode(final_encrypted_base64)
            # 第二步：AES解密
            key = b"vq1ljMB0hRWRKnRDDraM8fE0fLssjWhM"
            cipher = AES.new(key, AES.MODE_ECB)
            # 解密数据
            decrypted_padded_data = cipher.decrypt(encrypted_data)
            # 第三步：去除填充
            try:
                decrypted_data = unpad(decrypted_padded_data, AES.block_size)
            except ValueError as e:
                log_message(f"去除填充时出错: {e}", "ERROR")
                # 如果标准unpad失败，尝试手动处理
                decrypted_data = decrypted_padded_data.rstrip(b'\x00')
            # 第四步：解码base64字符串
            base64_decoded_str = decrypted_data.decode('utf-8')
            json_bytes = base64.b64decode(base64_decoded_str)
            json_str = json_bytes.decode('utf-8')
            # 第五步：解析JSON
            self.o_database = json.loads(json_str)
            # LOG
            log_message(f"已从数据库({self.o_database['name']})中导入了 {len(self.o_database['db_data'])} 条内容。该数据库的创建日期为:{timestamp_to_datetime(self.o_database['time']).strftime('%Y-%m-%d %H:%M:%S')} ({self.o_database['time']}),该数据库的注意事项为:{self.o_database['notes']}", "INFO")
        except Exception as e:
            log_message(f"数据库初始化失败: {e}", "ERROR")
            self.o_database = {"name": "空数据库", "time": 0, "notes": "数据库加载失败", "db_data": []}

    # 生成搜索会话ID
    def generate_search_id(self, user_id, keyword):
        # 生成唯一的搜索会话ID
        import hashlib
        import time
        unique_str = f"{user_id}_{keyword}_{time.time()}"
        return hashlib.md5(unique_str.encode()).hexdigest()[:8]

    # 处理 /start 命令
    def start_(self, message):
        # LOG
        log_message(f"用户 {get_user_display_name(message.from_user)}({message.from_user.id}) 发送了 /start 命令", "INFO")
        
        # 构建完整的欢迎消息（包含数据库信息）
        full_welcome_message = self.WelcomeMessage
        
        # 发送欢迎消息和按钮
        self.bot.send_message(
            message.chat.id, 
            full_welcome_message, 
            parse_mode="HTML",
            reply_markup=self.create_main_keyboard()
        )

    # 显示用户协议
    def ShowUserAgreement_(self, message):
        # 发送用户协议
        self.bot.send_message(
            message.chat.id, 
            self.UserAgreement, 
            parse_mode="HTML",
            reply_markup=self.create_main_keyboard()
        )
    
    # 搜索功能 - 带分页
    def handle_search(self, message, keyword=None):
        # 处理搜索功能（带分页）
        if not self.o_database or not self.o_database.get("db_data"):
            self.bot.reply_to(message, "❌ 数据库未加载或为空")
            return
        
        user_id = message.from_user.id
        
        # 检查搜索限制
        can_search, limit_message = self.check_search_limit(user_id)
        if not can_search:
            self.bot.reply_to(message, limit_message)
            return
        
        # 如果没有提供关键词，从消息中提取
        if keyword is None:
            if message.text.startswith("搜索 "):
                keyword = message.text[3:].strip()
            else:
                keyword = message.text.strip()
        
        if not keyword:
            self.bot.send_message(
                message.chat.id,
                "🔍 请输入搜索关键词\n\n格式：<code>搜索 关键词</code>\n或直接发送关键词",
                parse_mode="HTML",
                reply_markup=self.create_main_keyboard()
            )
            return
        
        # 执行搜索
        results = search_in_descriptions(self.o_database, keyword)
        
        if not results:
            self.bot.send_message(
                message.chat.id,
                f"🔍 没有找到包含「{keyword}」的代码介绍",
                parse_mode='HTML',
                reply_markup=self.create_main_keyboard()
            )
            return
        
        # 生成搜索会话ID
        search_id = self.generate_search_id(user_id, keyword)
        
        # 存储搜索会话
        self.user_search_sessions[search_id] = {
            'user_id': user_id,
            'keyword': keyword,
            'results': results,
            'current_page': 1,
            'total_pages': len(results),
            'created_time': datetime.datetime.now()
        }
        
        # LOG
        log_message(f"用户 {get_user_display_name(message.from_user)}({user_id}) 搜索关键词: {keyword}, 找到 {len(results)} 条结果", "INFO")
        
        # 显示第一页
        self.show_search_page(message.chat.id, search_id, 1, message.message_id)
        
        # 显示限制提示信息
        if limit_message:
            self.bot.send_message(message.chat.id, limit_message)

    # 显示搜索结果的指定页面
    def show_search_page(self, chat_id, search_id, page_number, reply_to_message_id=None):
        # 显示搜索结果的指定页面
        if search_id not in self.user_search_sessions:
            self.bot.send_message(chat_id, "❌ 搜索会话已过期，请重新搜索")
            return
        
        session = self.user_search_sessions[search_id]
        results = session['results']
        total_pages = len(results)
        user_id = session['user_id']
        
        # 检查翻页限制（非VIP用户最多6页）
        if not self.check_page_limit(user_id, page_number):
            self.bot.send_message(chat_id, "❌ 非VIP用户最多查看6页内容\n\n⭐ 升级VIP可查看全部结果！")
            page_number = 6  # 限制在6页
        
        # 确保页码在有效范围内
        page_number = max(1, min(page_number, total_pages))
        session['current_page'] = page_number
        
        # 获取当前页的数据
        current_item = results[page_number - 1]
        code, code_type, description = current_item
        
        # 代码种类映射
        type_names = {
            1: "推荐使用 @ShowFilesBot 必要时使用 @FilesPan1Bot (FilesDriveBLGA与旧密文)",
            2: "@ShowFilesBot 或 @MediaBKbot", 
            3: "@ShowFilesBot",
            4: "@ShowFilesBot (DataPanBot)",
            5: "@ShowFilesBot (FilesPan1Bot)",
            6: "南天门解码器( @ntmjmqbot )"
        }
        type_name = type_names.get(code_type)
        
        # 构建消息内容
        response = f"🔍 <b>搜索「{session['keyword']}」</b>\n"
        response += f"📄 <i>第 {page_number}/{total_pages} 页</i>\n"
        
        # 显示翻页限制提示
        if not self.is_vip_user(user_id) and total_pages > 6:
            response += f"<i>💡 非VIP用户最多查看6页内容</i>\n\n"
        else:
            response += "\n"
        
        response += f"<b>📁 代码适用解码器:</b> {type_name}\n"
        response += f"<b>🔤 代码内容:</b>\n<code>{code}</code>\n\n"
        response += f"<b>📝 代码介绍:</b>\n<i>{description}</i>\n\n"
        
        response += f"<i>💡 使用下方按钮浏览其他结果</i>"
        
        # 创建分页键盘
        markup = self.create_pagination_keyboard(page_number, total_pages, search_id)
        
        # 发送或编辑消息
        if reply_to_message_id:
            # 编辑现有消息
            try:
                self.bot.edit_message_text(
                    response,
                    chat_id,
                    reply_to_message_id,
                    parse_mode='HTML',
                    reply_markup=markup
                )
            except Exception as e:
                # 如果编辑失败，发送新消息
                log_message(f"编辑消息失败: {e}", "ERROR")
                self.bot.send_message(
                    chat_id,
                    response,
                    parse_mode='HTML',
                    reply_markup=markup
                )
        else:
            # 发送新消息
            self.bot.send_message(
                chat_id,
                response,
                parse_mode='HTML',
                reply_markup=markup
            )
    
    # 处理分页回调
    def handle_pagination_callback(self, call):
        # 处理分页回调
        try:
            data = call.data
            
            if data.startswith("page_"):
                # 解析页码信息
                parts = data.split("_")
                if len(parts) >= 3:
                    search_id = parts[1]
                    page_number = int(parts[2])
                    
                    # 编辑现有消息显示指定页面
                    self.show_search_page(call.message.chat.id, search_id, page_number, call.message.message_id)
                    
                    # 回答回调查询
                    self.bot.answer_callback_query(call.id, f"切换到第 {page_number} 页")
            
            elif data.startswith("jump_"):
                # 跳转到指定页面
                search_id = data.split("_")[1]
                # 请求用户输入页码
                msg = self.bot.send_message(
                    call.message.chat.id,
                    "🔢 请输入要跳转的页码：",
                    reply_to_message_id=call.message.message_id
                )
                # 注册下一步处理器
                self.bot.register_next_step_handler(msg, self.handle_jump_page, search_id)
                self.bot.answer_callback_query(call.id, "请输入页码")
            
            elif data == "new_search":
                # 重新搜索
                self.bot.delete_message(call.message.chat.id, call.message.message_id)
                self.bot.send_message(
                    call.message.chat.id,
                    "🔍 请输入新的搜索关键词：",
                    parse_mode="HTML",
                    reply_markup=self.create_main_keyboard()
                )
                self.bot.answer_callback_query(call.id, "开始新的搜索")
            
            elif data == "back_to_main":
                # 返回主页
                self.bot.delete_message(call.message.chat.id, call.message.message_id)
                self.start_(call.message)
                self.bot.answer_callback_query(call.id, "返回主页")
            
            elif data == "page_info":
                self.bot.answer_callback_query(call.id, "当前页面信息")
            
            # VIP相关回调
            elif data == "vip_buy":
                self.show_vip_purchase_options(call.message)
                self.bot.answer_callback_query(call.id, "VIP购买选项")
            elif data == "vip_status":
                self.show_vip_status(call.message)
                self.bot.answer_callback_query(call.id, "VIP状态")
            elif data == "vip_back":
                # 返回VIP服务菜单
                self.handle_vip_service(call.message)
                self.bot.answer_callback_query(call.id, "返回VIP服务")
                
        except Exception as e:
            log_message(f"处理分页回调时出错: {e}", "ERROR")
            self.bot.answer_callback_query(call.id, "操作失败，请重试")
    
    # 处理跳转页面输入
    def handle_jump_page(self, message, search_id):
        try:
            page_number = int(message.text.strip())
            # 删除用户输入的消息
            self.bot.delete_message(message.chat.id, message.message_id)
            # 跳转到指定页面，使用当前消息的ID
            self.show_search_page(message.chat.id, search_id, page_number, message.message_id)
        except ValueError:
            self.bot.send_message(message.chat.id, "❌ 请输入有效的页码数字")
        except Exception as e:
            log_message(f"处理跳转页面失败: {e}", "ERROR")
            self.bot.send_message(message.chat.id, "❌ 跳转失败，请重试")

    # 显示VIP购买选项
    def show_vip_purchase_options(self, message):
        vip_options = """
    <b>⭐ VIP会员服务</b>

    🎁 <b>VIP特权：</b>
    • 无限制搜索次数
    • 查看全部搜索结果（无6页限制）
    • 优先技术支持

    💰 <b>价格方案：</b>
    • 1个月 VIP - 15元
    • 3个月 VIP - 40元 (省5元)
    • 6个月 VIP - 75元 (省15元)
    • 12个月 VIP - 140元 (省40元)

    💳 <b>购买方式：</b>
    联系TG @JLmn7
    """
        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("📊 VIP状态", callback_data="vip_status"),
            InlineKeyboardButton("⬅️ 返回上一页", callback_data="vip_back")
        )
        
        try:
            self.bot.edit_message_text(
                vip_options,
                message.chat.id,
                message.message_id,
                parse_mode='HTML',
                reply_markup=markup
            )
        except Exception as e:
            log_message(f"编辑VIP购买选项失败: {e}", "ERROR")
    
    def show_vip_status(self, message):
        user_id = message.from_user.id
        is_vip = self.is_vip_user(user_id)
        remaining_time = self.get_vip_remaining_time(user_id)
        if is_vip:
            status_text = f"""
    <b>⭐ 您的VIP状态</b>

    ✅ <b>状态：</b> VIP会员
    ⏰ <b>剩余时间：</b> {remaining_time}
    🎉 <b>享受所有VIP特权！</b>
    """
        else:
            status_text = """
    <b>⭐ 您的VIP状态</b>

    ❌ <b>状态：</b> 非VIP会员
    📊 <b>当前限制：</b>
    • 每天最多搜索10次
    • 最多查看6页结果

    💡 <b>升级VIP享受：</b>
    • 无限制搜索次数
    • 查看全部搜索结果
    • 优先技术支持
    """
        
        markup = InlineKeyboardMarkup()
        if not is_vip:
            markup.row(InlineKeyboardButton("💰 购买VIP", callback_data="vip_buy"))
        markup.row(InlineKeyboardButton("⬅️ 返回上一页", callback_data="vip_back"))
        
        try:
            self.bot.edit_message_text(
                status_text,
                message.chat.id,
                message.message_id,
                parse_mode='HTML',
                reply_markup=markup
            )
        except Exception as e:
            log_message(f"编辑VIP状态失败: {e}", "ERROR")
    
    # 处理VIP服务按钮
    def handle_vip_service(self, message):
        # 发送VIP服务菜单
        vip_menu = """
<b>⭐ VIP会员服务</b>

选择您需要的服务：
"""
        self.bot.send_message(
            message.chat.id,
            vip_menu,
            parse_mode='HTML',
            reply_markup=self.create_vip_keyboard()
        )
    
    # 管理员命令处理
    def handle_admin_command(self, message):
        if message.from_user.id not in self.ADMIN_IDS:
            self.bot.reply_to(message, "❌ 无权访问管理员功能")
            return
        
        admin_menu = """
<b>⚙️ 管理员面板</b>

选择要管理的功能：
"""
        admin_menu = admin_menu + "\n\n" + self.get_database_info()
        self.bot.send_message(
            message.chat.id,
            admin_menu,
            parse_mode='HTML',
            reply_markup=self.create_admin_keyboard()
        )
    
    # 处理管理员功能
    def handle_admin_functions(self, message):
        if message.from_user.id not in self.ADMIN_IDS:
            return
        
        if message.text == "📊 统计信息":
            self.show_admin_stats(message)
        elif message.text == "👥 用户管理":
            self.show_user_management(message)
        elif message.text == "⭐ VIP管理":
            self.show_vip_management(message)
        elif message.text == "🔄 重置限制":
            self.reset_user_limits(message)
        elif message.text == "🏠 返回主菜单":
            self.start_(message)
    
    # 显示管理员统计信息
    def show_admin_stats(self, message):
        total_vip = len(self.vip_users)
        today_searches = sum(self.user_search_counts.values())
        active_sessions = len(self.user_search_sessions)
        
        stats_text = f"""
<b>📊 系统统计信息</b>

⭐ VIP用户数: {total_vip}
🔍 今日搜索次数: {today_searches}
💬 活跃会话数: {active_sessions}
📁 数据库条目: {len(self.o_database.get('db_data', []))}
"""
        self.bot.send_message(message.chat.id, stats_text, parse_mode='HTML')
    
    # 显示用户管理
    def show_user_management(self, message):
        user_management = """
<b>👥 用户管理</b>

发送用户ID进行管理：

• 添加VIP: <code>/vip 用户ID 天数</code>
• 移除VIP: <code>/unvip 用户ID</code>
• 查看用户: <code>/user 用户ID</code>

示例: <code>/vip 123456789 30</code>
"""
        self.bot.send_message(message.chat.id, user_management, parse_mode='HTML')
    
    # 显示VIP管理
    def show_vip_management(self, message):
        vip_count = len(self.vip_users)
        vip_list = "\n".join([f"• {user_id}" for user_id in list(self.vip_users.keys())[:10]])
        if len(self.vip_users) > 10:
            vip_list += f"\n• ... 还有 {len(self.vip_users) - 10} 个用户"
        
        vip_management = f"""
<b>⭐ VIP用户管理</b>

当前VIP用户数: {vip_count}

{vip_list if vip_list else "暂无VIP用户"}
"""
        self.bot.send_message(message.chat.id, vip_management, parse_mode='HTML')
    
    # 重置用户限制
    def reset_user_limits(self, message):
        self.user_search_counts = {}
        self.save_user_search_counts()
        self.bot.reply_to(message, "✅ 已重置所有用户搜索限制")
    
    # 处理管理员文本命令
    def handle_admin_text_commands(self, message):
        if message.from_user.id not in self.ADMIN_IDS:
            return
        
        text = message.text.strip()
        
        if text.startswith("/vip "):
            self.handle_add_vip_command(message)
        elif text.startswith("/unvip "):
            self.handle_remove_vip_command(message)
        elif text.startswith("/user "):
            self.handle_user_info_command(message)
    
    # 处理添加VIP命令
    def handle_add_vip_command(self, message):
        try:
            parts = message.text.split()
            if len(parts) >= 3:
                user_id = int(parts[1])
                days = int(parts[2])
                self.add_vip_user(user_id, days)
                self.bot.reply_to(message, f"✅ 已为用户 {user_id} 添加 {days} 天VIP")
            else:
                self.bot.reply_to(message, "❌ 格式错误，使用: /vip 用户ID 天数")
        except Exception as e:
            self.bot.reply_to(message, f"❌ 添加VIP失败: {e}")
    
    # 处理移除VIP命令
    def handle_remove_vip_command(self, message):
        try:
            user_id = int(message.text.split()[1])
            user_id_str = str(user_id)
            if user_id_str in self.vip_users:
                del self.vip_users[user_id_str]
                self.save_vip_users()
                self.bot.reply_to(message, f"✅ 已移除用户 {user_id} 的VIP权限")
            else:
                self.bot.reply_to(message, f"❌ 用户 {user_id} 不是VIP")
        except Exception as e:
            self.bot.reply_to(message, f"❌ 移除VIP失败: {e}")
    
    # 处理用户信息命令
    def handle_user_info_command(self, message):
        try:
            user_id = int(message.text.split()[1])
            user_id_str = str(user_id)
            is_vip = self.is_vip_user(user_id)
            search_count = self.user_search_counts.get(user_id_str, 0)
            
            user_info = f"""
<b>👤 用户信息</b>

🆔 ID: <code>{user_id}</code>
⭐ VIP状态: {'✅ 是' if is_vip else '❌ 否'}
🔍 今日搜索: {search_count} 次
"""
            self.bot.reply_to(message, user_info, parse_mode='HTML')
        except Exception as e:
            self.bot.reply_to(message, f"❌ 获取用户信息失败: {e}")
    
    # 显示帮助信息
    def show_help(self, message):
        # 显示帮助信息
        self.bot.send_message(
            message.chat.id,
            self.HelpMessage,
            parse_mode='HTML',
            reply_markup=self.create_main_keyboard()
        )
    
    # 显示用户信息
    def show_user_info(self, message):
        # 显示用户信息
        user = message.from_user
        is_vip = self.is_vip_user(user.id)
        vip_status = "✅ VIP会员" if is_vip else "❌ 非VIP会员"
        remaining_time = self.get_vip_remaining_time(user.id) if is_vip else "无"
        search_count = self.user_search_counts.get(str(user.id), 0)
        remaining_searches = 10 - search_count if not is_vip else "无限制"
        
        user_info = f"""
<b>👤 用户信息</b>

🆔 ID: <code>{user.id}</code>
👤 姓名: {user.first_name or '未设置'}
📛 用户名: @{user.username or '未设置'}
⭐ VIP状态: {vip_status}
⏰ VIP剩余: {remaining_time}
🔍 今日搜索: {search_count} 次
📄 剩余搜索: {remaining_searches} 次
"""
        self.bot.send_message(
            message.chat.id,
            user_info,
            parse_mode='HTML',
            reply_markup=self.create_main_keyboard()
        )
    
    # 清理过期的搜索会话
    def cleanup_old_sessions(self):
        # 清理过期的搜索会话
        current_time = datetime.datetime.now()
        expired_sessions = []
        
        for search_id, session in self.user_search_sessions.items():
            # 如果会话创建时间超过1小时，则标记为过期
            if (current_time - session['created_time']).total_seconds() > 3600:
                expired_sessions.append(search_id)
        
        for search_id in expired_sessions:
            del self.user_search_sessions[search_id]
        
        if expired_sessions:
            log_message(f"清理了 {len(expired_sessions)} 个过期搜索会话", "CLEANUP")
    
    # 设置消息处理器
    def setup_handlers(self):
        # 处理 /start 命令
        @self.bot.message_handler(commands=["start"])
        def start(message):
            self.start_(message)
        
        # 处理 /admin 命令
        @self.bot.message_handler(commands=["admin"])
        def admin(message):
            self.handle_admin_command(message)
        
        # 处理"使用协议"关键词
        @self.bot.message_handler(regexp=r"^使用协议$")
        def ShowUserAgreement(message):
            self.ShowUserAgreement_(message)
        
        # 处理搜索命令
        @self.bot.message_handler(regexp=r'^搜索\s+.+')
        def handle_search_command(message):
            self.handle_search(message)
        
        # 处理主菜单按钮
        @self.bot.message_handler(func=lambda message: message.text in [
            "📜 使用协议", "ℹ️ 帮助信息", "👤 我的信息", "⭐ VIP服务"
        ])
        def handle_main_menu(message):
            if message.text == "📜 使用协议":
                self.ShowUserAgreement_(message)
            elif message.text == "ℹ️ 帮助信息":
                self.show_help(message)
            elif message.text == "👤 我的信息":
                self.show_user_info(message)
            elif message.text == "⭐ VIP服务":
                self.handle_vip_service(message)
        
        # 处理管理员功能按钮
        @self.bot.message_handler(func=lambda message: message.text in [
            "📊 统计信息", "👥 用户管理", "⭐ VIP管理", "🔄 重置限制", "🏠 返回主菜单"
        ])
        def handle_admin_buttons(message):
            self.handle_admin_functions(message)
        
        # 处理管理员文本命令
        @self.bot.message_handler(func=lambda message: message.text.startswith(('/vip ', '/unvip ', '/user ')))
        def handle_admin_text(message):
            self.handle_admin_text_commands(message)
        
        # 处理分页回调
        @self.bot.callback_query_handler(func=lambda call: True)
        def handle_callback(call):
            self.handle_pagination_callback(call)
        
        # 处理所有其他消息
        @self.bot.message_handler(func=lambda message: True)
        def search(message):
            self.handle_search(message)
    
    # 运行机器人主循环
    def run(self):
        # 检查Token是否有效
        if not self.BOT_TOKEN:
            log_message("未找到 TELEGRAM_BOT_TOKEN 环境变量", "ERROR")
            return
        
        try:
            # 创建Telegram机器人实例
            self.bot = telebot.TeleBot(self.BOT_TOKEN)
            log_message("机器人初始化成功", "OK")
            
            # 设置消息处理器
            self.setup_handlers()
            
            # 开始机器人轮询
            log_message("机器人开始运行...", "START")
            self.bot.polling()
            
        except Exception as e:
            # 捕获并打印异常信息
            log_message(f"{e}", "ERROR")

# MAIN 程序入口点
if __name__ == "__main__":
    # 创建机器人实例
    bot_instance = TelegramBot()
    # 初始化数据库
    bot_instance.initDataBase()
    # 启动机器人
    bot_instance.run()
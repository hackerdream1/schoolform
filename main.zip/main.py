# 版权所有 (C) 2025 Muttix 保留所有权利
# 项目名称: UU_Search_TGBot (Telegram文件代码搜索器机器人)
# 文件名称: main.py
# Email: sunmutian88@gmail.com

# 引入库
import os
import telebot
import json
import gzip
import base64
import datetime
import time
import sys
import random
import re
import zipfile
import tempfile
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
from dotenv import load_dotenv
from telebot.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove, InlineKeyboardMarkup, InlineKeyboardButton

# ------------------ 全局变量 ------------------ #

# 系统级重启次数限制
MAX_SYSTEM_RESTARTS = 256

# 设置更大的重启次数限制
MAX_RESTART_COUNT = 2048

# 日志文件路径
LOG_FILEPATH = None

# 数据目录路径
DATA_DIR = "./data/appdata"
LOG_DIR = "./log"
TEMP_DIR = "./temp"

# 用户请求频率限制
USER_REQUEST_LIMITS = {}  # 存储用户请求时间戳
USER_SEARCH_PATTERNS = {}  # 存储用户搜索模式

# 频率限制配置
REQUEST_LIMIT_WINDOW = 30  # 时间窗口(秒)
MAX_REQUESTS_PER_WINDOW = 20  # 每个窗口内最大请求数
SAME_CONTENT_LIMIT = 3  # 相同内容限制次数
BUFFER_TIME = 15  # 缓冲时间（秒）
MAX_RANDOM_LIMIT = 20  # 单个窗口时间内最大随机次数


# 随机次数限制
MAX_RANDOM_PER_DAY_NON_VIP = 10  # 非VIP用户每天最多随机次数

# 购买链接
GO_BUY_URL = "https://t.me/JLmn7"

# 广告位招租链接
GO_ADS_URL = "https://t.me/JLmn7"

# VIP价格表
VIP_PRICE_LIST = """
<b>⭐ VIP会员服务</b>

🎁 <b>VIP特权：</b>
• 无限制搜索次数
• 查看全部搜索结果（无6页限制）
• 优先技术支持

💰 <b>价格方案：</b>
• 1个月 VIP - 15元
• 3个月 VIP - 40元 (省5元)
• 6个月 VIP - 75元 (省15元)
• 12个月 VIP - 140元 (省40元)

💳 <b>购买方式：</b>
联系TG @JLmn7
"""

# ------------------ 全局变量 - END ------------------ #

# ------------------ 工具函数 ------------------ #

# 将毫秒级时间戳转换为datetime对象
def timestamp_to_datetime(timestamp_ms):
    # 将毫秒转换为秒
    timestamp_sec = timestamp_ms / 1000.0
    return datetime.datetime.fromtimestamp(timestamp_sec)

# 获取当前时间戳（字符串格式）
def get_current_time():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# 确保数据目录存在
def ensure_data_dir():
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR, exist_ok=True)

# 确保日志目录存在
def ensure_log_dir():
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR, exist_ok=True)

# 确保TEMP目录存在
def ensure_temp_dir():
    if not os.path.exists(TEMP_DIR):
        os.makedirs(TEMP_DIR, exist_ok=True)

# 初始化日志系统
def init_log_system():
    global LOG_FILEPATH
    try:
        # 确保日志目录存在
        ensure_log_dir()
        
        # 创建日志文件名（使用启动时间戳）
        startup_time = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        log_filename = f"LOG_{startup_time}.log"
        LOG_FILEPATH = os.path.join(LOG_DIR, log_filename)
        
        # 创建日志文件并写入启动信息
        with open(LOG_FILEPATH, "w", encoding="utf-8") as f:
            f.write(f"=== UU Search Bot 启动于 {get_current_time()} ===\n\n")
        
        print(f"[{get_current_time()}] [INIT] 日志系统初始化完成: {LOG_FILEPATH}")
        return True
        
    except Exception as e:
        print(f"[{get_current_time()}] [ERROR] 初始化日志系统失败: {e}")
        return False

# 日志记录函数
def log_message(message, log_type="INFO"):
    timestamp = get_current_time()
    log_entry = f"[{timestamp}] [{log_type}] {message}"
    
    # 打印到控制台
    print(log_entry)
    
    # 写入日志文件
    if LOG_FILEPATH:
        try:
            with open(LOG_FILEPATH, "a", encoding="utf-8") as f:
                f.write(log_entry + "\n")
        except Exception as e:
            print(f"[{get_current_time()}] [ERROR] 写入日志文件失败: {e}")

# 读取文本文件
def read_text_file(filepath):
    try:
        if os.path.exists(filepath):
            with open(filepath, "r", encoding="utf-8") as f:
                return f.read().strip()
        else:
            log_message(f"文件不存在: {filepath}", "ERROR")
            return None
    except Exception as e:
        log_message(f"读取文件失败 {filepath}: {e}", "ERROR")
        return None

# 搜索函数
def search_in_descriptions(database, keyword):
    # 在代码介绍中搜索关键词
    if not database or "db_data" not in database:
        return []
    
    results = []
    for item in database["db_data"]:
        if len(item) >= 3:  # 确保有代码介绍字段
            code, code_type, description = item
            if keyword.lower() in description.lower():
                results.append(item)
    
    return results

# 获取用户显示名称
def get_user_display_name(user):
    # 如果有 first_name 和 last_name
    if user.first_name and user.last_name:
        return f"{user.first_name} {user.last_name}"
    # 如果只有 first_name
    elif user.first_name:
        return user.first_name
    # 如果只有 last_name（这种情况很少见）
    elif user.last_name:
        return user.last_name
    # 如果有 username
    elif user.username:
        return f"@{user.username}"
    # 如果什么都没有，使用用户ID
    else:
        return f"用户{user.id}"

# 检查内容是否包含广告
def contains_advertisement(text):
    # 检查文本是否包含广告内容
    # 包括：@用户名、http链接、t.me链接、.com等
    if not text:
        return False
    
    # 广告检测规则
    ad_patterns = [
        r'@\w+',  # @用户名
        r'http[s]?://',  # http链接
        r't\.me/',  # t.me链接
        r'\.com',  # .com域名
        r'\.net',  # .net域名
        r'\.org',  # .org域名
        r'[\w]+@[A-Za-z]+(\.[A-Za-z0-9]+){1,2}',  # 邮箱
        r'^(?:[a-zA-Z0-9-]{1,63}\.)+[a-zA-Z]{2,}$', # 泛域名
        r'购买', '付费', '充值', '代理', '联系', '低价', "口碑老店", "值得信赖", "安全靠谱", "博彩","社工库", "开户", "面付"  # 中文广告词
    ]
    
    text_lower = text.lower()
    for pattern in ad_patterns:
        if re.search(pattern, text_lower):
            return True
    
    return False

# 加载热搜榜单数据
def load_hot_searches():
    try:
        ensure_data_dir()
        hot_searches_path = os.path.join(DATA_DIR, "hot_searches.json")
        if os.path.exists(hot_searches_path):
            with open(hot_searches_path, "r", encoding="utf-8") as f:
                return json.load(f)
        else:
            # 初始化为空的热搜数据
            default_hot_searches = {
                "last_updated": datetime.datetime.now().isoformat(),
                "search_counts": {}
            }
            # 保存默认数据
            with open(hot_searches_path, "w", encoding="utf-8") as f:
                json.dump(default_hot_searches, f, ensure_ascii=False, separators=(',', ':'))
            return default_hot_searches
    except Exception as e:
        log_message(f"加载热搜榜单失败: {e}", "ERROR")
        return None

# 保存热搜榜单数据
def save_hot_searches(hot_searches_data):
    try:
        ensure_data_dir()
        hot_searches_path = os.path.join(DATA_DIR, "hot_searches.json")
        with open(hot_searches_path, "w", encoding="utf-8") as f:
            json.dump(hot_searches_data, f, ensure_ascii=False, separators=(',', ':'))
        return True
    except Exception as e:
        log_message(f"保存热搜榜单失败: {e}", "ERROR")
        return False

# 更新热搜关键词计数
def update_hot_search_count(keyword):
    try:
        # 检查关键词是否包含广告内容
        if contains_advertisement(keyword):
            log_message(f"跳过广告关键词计数: {keyword}", "AD_DETECT")
            return False
            
        hot_searches_data = load_hot_searches()
        if not hot_searches_data:
            return False
        
        # 初始化search_counts如果不存在
        if "search_counts" not in hot_searches_data:
            hot_searches_data["search_counts"] = {}
        
        # 更新搜索计数
        if keyword in hot_searches_data["search_counts"]:
            hot_searches_data["search_counts"][keyword] += 1
        else:
            hot_searches_data["search_counts"][keyword] = 1
        
        # 更新最后修改时间
        hot_searches_data["last_updated"] = datetime.datetime.now().isoformat()
        
        return save_hot_searches(hot_searches_data)
        
    except Exception as e:
        log_message(f"更新热搜计数失败: {e}", "ERROR")
        return False

# 获取热搜榜单前10名（过滤广告内容）
def get_top_hot_searches(limit=10):
    try:
        hot_searches_data = load_hot_searches()
        if not hot_searches_data or "search_counts" not in hot_searches_data:
            return []
        
        # 过滤包含广告内容的关键词
        filtered_searches = {}
        for keyword, count in hot_searches_data["search_counts"].items():
            # 检查是否包含禁止内容
            if not contains_advertisement(keyword):
                filtered_searches[keyword] = count
        
        # 按搜索次数排序并取前limit名
        sorted_searches = sorted(
            filtered_searches.items(),
            key=lambda x: x[1],
            reverse=True
        )[:limit]
        
        return sorted_searches
    except Exception as e:
        log_message(f"获取热搜榜单失败: {e}", "ERROR")
        return []

# 加载用户使用记录
def load_user_usage_stats():
    try:
        ensure_data_dir()
        user_stats_path = os.path.join(DATA_DIR, "user_usage_stats.json")
        if os.path.exists(user_stats_path):
            with open(user_stats_path, "r", encoding="utf-8") as f:
                return json.load(f)
        else:
            return {}
    except Exception as e:
        log_message(f"加载用户使用记录失败: {e}", "ERROR")
        return {}

# 保存用户使用记录
def save_user_usage_stats(user_stats):
    try:
        ensure_data_dir()
        user_stats_path = os.path.join(DATA_DIR, "user_usage_stats.json")
        with open(user_stats_path, "w", encoding="utf-8") as f:
            json.dump(user_stats, f, ensure_ascii=False, separators=(',', ':'))
        return True
    except Exception as e:
        log_message(f"保存用户使用记录失败: {e}", "ERROR")
        return False

# 更新用户使用记录
def update_user_usage_stats(user_id, action="search", keyword=None):
    try:
        user_stats = load_user_usage_stats()
        user_id_str = str(user_id)
        current_time = datetime.datetime.now().isoformat()
        
        if user_id_str not in user_stats:
            user_stats[user_id_str] = {
                "first_seen": current_time,
                "last_active": current_time,
                "total_searches": 0,
                "vip_status": False,
                "search_keywords": [],
                "actions": []
            }
        
        user_stats[user_id_str]["last_active"] = current_time
        
        if action == "search":
            user_stats[user_id_str]["total_searches"] = user_stats[user_id_str].get("total_searches", 0) + 1
            if keyword:
                user_stats[user_id_str]["search_keywords"].append({
                    "keyword": keyword,
                    "time": current_time
                })
                # 只保留最近50个搜索关键词
                user_stats[user_id_str]["search_keywords"] = user_stats[user_id_str]["search_keywords"][-50:]
        
        user_stats[user_id_str]["actions"].append({
            "action": action,
            "time": current_time,
            "keyword": keyword if action == "search" else None
        })
        
        # 只保留最近100个操作记录
        user_stats[user_id_str]["actions"] = user_stats[user_id_str]["actions"][-100:]
        
        return save_user_usage_stats(user_stats)
        
    except Exception as e:
        log_message(f"更新用户使用记录失败: {e}", "ERROR")
        return False

# 加载封禁用户列表
def load_banned_users():
    try:
        ensure_data_dir()
        banned_users_path = os.path.join(DATA_DIR, "banned_users.json")
        if os.path.exists(banned_users_path):
            with open(banned_users_path, "r", encoding="utf-8") as f:
                return json.load(f)
        else:
            return {}
    except Exception as e:
        log_message(f"加载封禁用户列表失败: {e}", "ERROR")
        return {}

# 保存封禁用户列表
def save_banned_users(banned_users):
    try:
        ensure_data_dir()
        banned_users_path = os.path.join(DATA_DIR, "banned_users.json")
        with open(banned_users_path, "w", encoding="utf-8") as f:
            json.dump(banned_users, f, ensure_ascii=False, separators=(',', ':'))
        return True
    except Exception as e:
        log_message(f"保存封禁用户列表失败: {e}", "ERROR")
        return False

# 检查用户是否被封禁
def is_user_banned(user_id):
    try:
        banned_users = load_banned_users()
        return str(user_id) in banned_users
    except Exception as e:
        log_message(f"检查用户封禁状态失败: {e}", "ERROR")
        return False

# 封禁用户
def ban_user(user_id, reason="违反使用规则", admin_id=None):
    try:
        banned_users = load_banned_users()
        user_id_str = str(user_id)
        
        banned_users[user_id_str] = {
            "banned_time": datetime.datetime.now().isoformat(),
            "reason": reason,
            "banned_by": admin_id
        }
        
        if save_banned_users(banned_users):
            log_message(f"用户 {user_id} 已被封禁，原因: {reason}", "BAN")
            return True
        return False
    except Exception as e:
        log_message(f"封禁用户失败: {e}", "ERROR")
        return False

# 解封用户
def unban_user(user_id):
    try:
        banned_users = load_banned_users()
        user_id_str = str(user_id)
        
        if user_id_str in banned_users:
            del banned_users[user_id_str]
            if save_banned_users(banned_users):
                log_message(f"用户 {user_id} 已解封", "UNBAN")
                return True
        return False
    except Exception as e:
        log_message(f"解封用户失败: {e}", "ERROR")
        return False

# 加载VIP用户数据
def load_vip_users():
    try:
        ensure_data_dir()
        vip_users_path = os.path.join(DATA_DIR, "vip_users.json")
        if os.path.exists(vip_users_path):
            with open(vip_users_path, "r", encoding="utf-8") as f:
                return json.load(f)
        else:
            return {}
    except Exception as e:
        log_message(f"加载VIP用户数据失败: {e}", "ERROR")
        return {}

# 保存VIP用户数据
def save_vip_users(vip_users):
    try:
        ensure_data_dir()
        vip_users_path = os.path.join(DATA_DIR, "vip_users.json")
        with open(vip_users_path, "w", encoding="utf-8") as f:
            json.dump(vip_users, f, ensure_ascii=False, separators=(',', ':'))
        return True
    except Exception as e:
        log_message(f"保存VIP用户数据失败: {e}", "ERROR")
        return False

# 加载用户搜索次数
def load_user_search_counts():
    try:
        ensure_data_dir()
        search_counts_path = os.path.join(DATA_DIR, "user_search_counts.json")
        if os.path.exists(search_counts_path):
            with open(search_counts_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                # 检查日期，如果是新的一天则重置计数
                current_date = datetime.datetime.now().strftime("%Y-%m-%d")
                if data.get('date') != current_date:
                    return {}
                else:
                    return data.get('counts', {})
        else:
            return {}
    except Exception as e:
        log_message(f"加载用户搜索次数失败: {e}", "ERROR")
        return {}

# 保存用户搜索次数
def save_user_search_counts(user_search_counts):
    try:
        ensure_data_dir()
        search_counts_path = os.path.join(DATA_DIR, "user_search_counts.json")
        current_date = datetime.datetime.now().strftime("%Y-%m-%d")
        data = {
            'date': current_date,
            'counts': user_search_counts
        }
        with open(search_counts_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, separators=(',', ':'))
        return True
    except Exception as e:
        log_message(f"保存用户搜索次数失败: {e}", "ERROR")
        return False

# 加载用户随机次数
def load_user_random_counts():
    try:
        ensure_data_dir()
        random_counts_path = os.path.join(DATA_DIR, "user_random_counts.json")
        if os.path.exists(random_counts_path):
            with open(random_counts_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                # 检查日期，如果是新的一天则重置计数
                current_date = datetime.datetime.now().strftime("%Y-%m-%d")
                if data.get('date') != current_date:
                    return {}
                else:
                    return data.get('counts', {})
        else:
            return {}
    except Exception as e:
        log_message(f"加载用户随机次数失败: {e}", "ERROR")
        return {}

# 保存用户随机次数
def save_user_random_counts(user_random_counts):
    try:
        ensure_data_dir()
        random_counts_path = os.path.join(DATA_DIR, "user_random_counts.json")
        current_date = datetime.datetime.now().strftime("%Y-%m-%d")
        data = {
            'date': current_date,
            'counts': user_random_counts
        }
        with open(random_counts_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, separators=(',', ':'))
        return True
    except Exception as e:
        log_message(f"保存用户随机次数失败: {e}", "ERROR")
        return False

# 加载广告数据
def load_advertisements():
    try:
        ensure_data_dir()
        ads_path = os.path.join(DATA_DIR, "advertisements.json")
        if os.path.exists(ads_path):
            with open(ads_path, "r", encoding="utf-8") as f:
                return json.load(f)
        else:
            # 初始化广告数据
            default_ads = {
                "enabled": True,
                "ads": [
                    {
                        "id": 1,
                        "text": "广告位招租",
                        "url": "https://t.me/your_channel",
                        "enabled": True,
                        "clicks": 0,
                        "impressions": 0
                    }
                ]
            }
            with open(ads_path, "w", encoding="utf-8") as f:
                json.dump(default_ads, f, ensure_ascii=False, separators=(',', ':'))
            return default_ads
    except Exception as e:
        log_message(f"加载广告数据失败: {e}", "ERROR")
        return None

# 保存广告数据
def save_advertisements(ads_data):
    try:
        ensure_data_dir()
        ads_path = os.path.join(DATA_DIR, "advertisements.json")
        with open(ads_path, "w", encoding="utf-8") as f:
            json.dump(ads_data, f, ensure_ascii=False, separators=(',', ':'))
        return True
    except Exception as e:
        log_message(f"保存广告数据失败: {e}", "ERROR")
        return False

# 检查用户请求频率
def check_request_frequency(user_id, content=None):
    current_time = time.time()
    user_id_str = str(user_id)
    
    # 初始化用户记录
    if user_id_str not in USER_REQUEST_LIMITS:
        USER_REQUEST_LIMITS[user_id_str] = {
            'timestamps': [],
            'last_buffer_time': 0
        }
    
    if user_id_str not in USER_SEARCH_PATTERNS:
        USER_SEARCH_PATTERNS[user_id_str] = {}
    
    user_limits = USER_REQUEST_LIMITS[user_id_str]
    user_patterns = USER_SEARCH_PATTERNS[user_id_str]
    
    # 检查是否在缓冲期内
    if current_time - user_limits['last_buffer_time'] < BUFFER_TIME:
        return False, "缓冲期"
    
    # 清理过期的请求记录
    user_limits['timestamps'] = [
        timestamp for timestamp in user_limits['timestamps']
        if current_time - timestamp < REQUEST_LIMIT_WINDOW
    ]
    
    # 检查相同内容限制
    if content and content.strip():
        content_key = content.strip().lower()
        if content_key not in user_patterns:
            user_patterns[content_key] = []
        
        # 清理过期的相同内容记录
        user_patterns[content_key] = [
            timestamp for timestamp in user_patterns[content_key]
            if current_time - timestamp < REQUEST_LIMIT_WINDOW
        ]
        
        # 检查相同内容次数
        if content_key != "🎲 全库随机":
            # 如果不是全库随机搜索
            if len(user_patterns[content_key]) >= SAME_CONTENT_LIMIT:
                user_limits['last_buffer_time'] = current_time
                return False, "相同内容"
        elif len(user_patterns[content_key]) >= MAX_RANDOM_LIMIT:
            # 如果是全库随机搜索
            user_limits['last_buffer_time'] = current_time
            return False, "频繁请求"
        
        # 记录当前相同内容请求
        user_patterns[content_key].append(current_time)
    
    # 检查总请求次数限制
    if len(user_limits['timestamps']) >= MAX_REQUESTS_PER_WINDOW:
        user_limits['last_buffer_time'] = current_time
        return False, "频繁请求"
    
    # 记录当前请求
    user_limits['timestamps'].append(current_time)
    return True, None

# 清理过期的频率记录
def cleanup_old_frequency_records():
    current_time = time.time()
    expired_users = []
    
    for user_id_str, user_limits in USER_REQUEST_LIMITS.items():
        # 清理过期的请求记录
        user_limits['timestamps'] = [
            timestamp for timestamp in user_limits['timestamps']
            if current_time - timestamp < REQUEST_LIMIT_WINDOW * 2
        ]
        
        # 如果用户没有有效记录且不在缓冲期，标记为待删除
        if (not user_limits['timestamps'] and 
            current_time - user_limits['last_buffer_time'] > BUFFER_TIME * 2):
            expired_users.append(user_id_str)
    
    # 清理搜索模式记录
    for user_id_str, user_patterns in USER_SEARCH_PATTERNS.items():
        for content_key, timestamps in list(user_patterns.items()):
            # 清理过期的相同内容记录
            user_patterns[content_key] = [
                timestamp for timestamp in timestamps
                if current_time - timestamp < REQUEST_LIMIT_WINDOW * 2
            ]
            
            # 如果内容记录为空，删除该内容键
            if not user_patterns[content_key]:
                del user_patterns[content_key]
        
        # 如果用户没有搜索模式记录，标记为待删除
        if not user_patterns and user_id_str not in expired_users:
            expired_users.append(user_id_str)
    
    # 删除过期用户记录
    for user_id_str in expired_users:
        if user_id_str in USER_REQUEST_LIMITS:
            del USER_REQUEST_LIMITS[user_id_str]
        if user_id_str in USER_SEARCH_PATTERNS:
            del USER_SEARCH_PATTERNS[user_id_str]

# ------------------ 工具函数 - END ------------------ #

# ------------------ Telegram 机器人主类 ------------------ #
class TelegramBot:
    # 从文件加载欢迎消息
    def load_welcome_message(self):
        content = read_text_file(self.WELCOME_MESSAGE_PATH)
        if content:
            log_message(f"已加载欢迎消息，长度: {len(content)} 字符", "INFO")
            return content
        else:
            log_message("欢迎消息文件不存在或读取失败", "ERROR")
            return "欢迎消息加载失败，请联系管理员。"

    # 从文件加载用户协议
    def load_user_agreement(self):
        content = read_text_file(self.USER_AGREEMENT_PATH)
        if content:
            log_message(f"已加载用户协议，长度: {len(content)} 字符", "INFO")
            return content
        else:
            log_message("用户协议文件不存在或读取失败", "ERROR")
            return "用户协议加载失败，请联系管理员。"

    # 从文件加载帮助信息
    def load_help_message(self):
        content = read_text_file(self.HELP_MESSAGE_PATH)
        if content:
            log_message(f"已加载帮助信息，长度: {len(content)} 字符", "INFO")
            return content
        else:
            log_message("帮助信息文件不存在或读取失败", "ERROR")
            return "帮助信息加载失败，请联系管理员。"

    # 初始化机器人配置
    def __init__(self):
        # 初始化日志系统
        if not init_log_system():
            print("日志系统初始化失败，程序退出")
            exit(1)

        # 加载.env文件中的环境变量
        load_dotenv()
        # 从环境变量获取机器人Token
        self.BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
        # 从环境变量获取文件路径
        self.WELCOME_MESSAGE_PATH = os.getenv("WELCOME_MESSAGE_PATH", "./data/welcome_message.txt")
        self.USER_AGREEMENT_PATH = os.getenv("USER_AGREEMENT_PATH", "./data/user_agreement.txt")
        self.HELP_MESSAGE_PATH = os.getenv("HELP_MESSAGE_PATH", "./data/help_message.txt")
        self.DEFAULT_DATABASE_PATH = os.getenv("DEFAULT_DATABASE_PATH")

        # 从环境变量获取广告最大展示条数
        self.MAX_ADS_DISPLAY = os.getenv("MAX_ADS_DISPLAY")

        # 管理员ID列表
        self.ADMIN_IDS = [int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip()]
        
        # LOG
        log_message(f"TELEGRAM_BOT_TOKEN = {self.BOT_TOKEN}", "ENV")
        log_message(f"WELCOME_MESSAGE_PATH = {self.WELCOME_MESSAGE_PATH}", "ENV")
        log_message(f"USER_AGREEMENT_PATH = {self.USER_AGREEMENT_PATH}", "ENV")
        log_message(f"HELP_MESSAGE_PATH = {self.HELP_MESSAGE_PATH}", "ENV")
        log_message(f"DEFAULT_DATABASE_PATH = {self.DEFAULT_DATABASE_PATH}", "ENV")
        log_message(f"ADMIN_IDS = {self.ADMIN_IDS}", "ENV")
        log_message(f"MAX_ADS_DISPLAY = {self.MAX_ADS_DISPLAY}", "ENV")
        
        # 初始化机器人实例
        self.bot = None
        # 初始化数据库
        self.o_database = None
        # 用户搜索状态存储
        self.user_search_sessions = {}
        # VIP用户数据
        self.vip_users = load_vip_users()
        # 用户搜索次数记录
        self.user_search_counts = load_user_search_counts()
        # 用户随机次数记录
        self.user_random_counts = load_user_random_counts()
        # 用户使用统计
        self.user_usage_stats = load_user_usage_stats()
        # 封禁用户列表
        self.banned_users = load_banned_users()
        # 广告数据
        self.advertisements = load_advertisements()
        
        # 从文件读取欢迎消息
        self.WelcomeMessage = self.load_welcome_message()
        # 从文件读取用户协议
        self.UserAgreement = self.load_user_agreement()
        # 从文件读取帮助信息
        self.HelpMessage = self.load_help_message()

    # 检查用户VIP状态
    def is_vip_user(self, user_id):
        # 管理员自动拥有VIP权限（无限制）
        if user_id in self.ADMIN_IDS:
            return True
        
        user_id_str = str(user_id)
        if user_id_str in self.vip_users:
            expiry_time = datetime.datetime.fromisoformat(self.vip_users[user_id_str]['expiry_time'])
            if expiry_time > datetime.datetime.now():
                return True
            else:
                # VIP已过期，删除记录
                del self.vip_users[user_id_str]
                save_vip_users(self.vip_users)
        return False

    # 获取VIP剩余时间
    def get_vip_remaining_time(self, user_id):
        # 管理员显示无限制
        if user_id in self.ADMIN_IDS:
            return "永久"
        
        user_id_str = str(user_id)
        if user_id_str in self.vip_users:
            expiry_time = datetime.datetime.fromisoformat(self.vip_users[user_id_str]['expiry_time'])
            remaining = expiry_time - datetime.datetime.now()
            if remaining.total_seconds() > 0:
                days = remaining.days
                hours = remaining.seconds // 3600
                return f"{days}天{hours}小时"
        return "无"

    # 检查用户搜索限制
    def check_search_limit(self, user_id):
        # 检查用户是否被封禁
        if is_user_banned(user_id):
            return False, "❌ 无权限"
        
        if self.is_vip_user(user_id):
            return True, None  # VIP用户无限制
        
        user_id_str = str(user_id)
        today_searches = self.user_search_counts.get(user_id_str, 0)
        
        if today_searches >= 10:  # 非VIP用户每天最多10次搜索
            return False, "❌ 今日搜索次数已达上限（10次）\n\n⭐ 升级VIP可享受无限制搜索！"
        
        # 更新搜索次数
        self.user_search_counts[user_id_str] = today_searches + 1
        save_user_search_counts(self.user_search_counts)
        
        remaining_searches = 10 - (today_searches + 1)
        if remaining_searches <= 3:
            return True, f"💡 今日剩余搜索次数：{remaining_searches}次\n⭐ 升级VIP享受无限制搜索！"
        
        return True, None

    # 检查用户随机限制
    def check_random_limit(self, user_id):
        # 检查用户是否被封禁
        if is_user_banned(user_id):
            return False, "❌ 无权限"
        
        if self.is_vip_user(user_id):
            return True, None  # VIP用户无限制
        
        user_id_str = str(user_id)
        today_randoms = self.user_random_counts.get(user_id_str, 0)
        
        if today_randoms >= MAX_RANDOM_PER_DAY_NON_VIP:
            return False, f"❌ 今日随机次数已达上限（{MAX_RANDOM_PER_DAY_NON_VIP}次）\n\n⭐ 升级VIP可享受无限制随机推荐！"
        
        # 更新随机次数
        self.user_random_counts[user_id_str] = today_randoms + 1
        save_user_random_counts(self.user_random_counts)
        
        remaining_randoms = MAX_RANDOM_PER_DAY_NON_VIP - (today_randoms + 1)
        if remaining_randoms <= 1:
            return True, f"💡 今日剩余随机次数：{remaining_randoms}次\n⭐ 升级VIP享受无限制随机推荐！"
        
        return True, None

    # 添加VIP用户
    def add_vip_user(self, user_id, days=30):
        user_id_str = str(user_id)
        expiry_time = datetime.datetime.now() + datetime.timedelta(days=days)
        self.vip_users[user_id_str] = {
            'expiry_time': expiry_time.isoformat(),
            'added_time': datetime.datetime.now().isoformat(),
            'days': days
        }
        save_vip_users(self.vip_users)
        log_message(f"用户 {user_id} 已添加VIP，有效期{days}天", "VIP")

    # 检查翻页限制（非VIP用户最多6页）
    def check_page_limit(self, user_id, page_number):
        if self.is_vip_user(user_id):
            return True  # VIP用户无限制
        
        if page_number > 6:  # 非VIP用户最多查看6页
            return False
        
        return True

    # 创建主菜单底部键盘
    def create_main_keyboard(self):
        markup = ReplyKeyboardMarkup(
            resize_keyboard=True,
            one_time_keyboard=False
        )
        
        # 根据VIP状态显示不同按钮
        markup.row("📜 使用协议", "ℹ️ 帮助信息")
        markup.row("👤 我的信息", "⭐ VIP服务")
        markup.row("🎲 全库随机", "🔥 热搜榜单")
        
        return markup

    # 创建VIP服务键盘
    def create_vip_keyboard(self):
        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("💰 联系购买", url = GO_BUY_URL),
            InlineKeyboardButton("📊 VIP状态", callback_data="vip_status")
        )
        markup.row(InlineKeyboardButton("🏠 返回主页", callback_data="back_to_main"))
        return markup

    # 创建分页内联键盘（带跳转功能）
    def create_pagination_keyboard(self, current_page, total_pages, search_id):
        markup = InlineKeyboardMarkup()
        
        # 页码信息
        page_info = f"{current_page}/{total_pages}"
        
        # 翻页按钮
        row_buttons = []
        if current_page > 1:
            row_buttons.append(InlineKeyboardButton("⬅️ 上一页", callback_data=f"page_{search_id}_{current_page-1}"))
        
        row_buttons.append(InlineKeyboardButton(f"📄 {page_info}", callback_data="page_info"))
        
        if current_page < total_pages:
            row_buttons.append(InlineKeyboardButton("下一页 ➡️", callback_data=f"page_{search_id}_{current_page+1}"))
        
        markup.row(*row_buttons)
        
        # 跳转页面按钮（仅VIP用户显示）
        if self.check_page_limit(999999, current_page + 1):  # 临时检查
            markup.row(InlineKeyboardButton("🔢 跳转到页面", callback_data=f"jump_{search_id}"))
        
        # 操作按钮
        markup.row(
            InlineKeyboardButton("🔄 重新搜索", callback_data="new_search"),
            InlineKeyboardButton("🏠 返回主页", callback_data="back_to_main")
        )
        
        return markup

    # 创建管理员键盘
    def create_admin_keyboard(self):
        markup = ReplyKeyboardMarkup(resize_keyboard=True)
        markup.row("📊 统计信息", "👥 用户管理")
        markup.row("⭐ VIP管理", "📁 日志管理")
        markup.row("🔄 重置限制", "📢 广播消息")
        markup.row("🚫 封禁管理", "🔥 热搜榜单管理")
        markup.row("📤 数据导出", "💬 用户私信")
        markup.row("📢 广告管理")
        markup.row("🏠 返回主菜单")
        return markup
    
    # 创建内容导出键盘
    def create_export_keyboard(self):
        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("📦 导出所有数据(.ZIP)", callback_data="export_full")
        )
        markup.row(InlineKeyboardButton("⬅️ 返回管理员", callback_data="back_to_admin"))
        return markup

    # 创建热搜管理键盘
    def create_hot_search_keyboard(self):
        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("📋 查看热搜", callback_data="hot_search_view"),
            InlineKeyboardButton("✏️ 修改热搜", callback_data="hot_search_edit")
        )
        markup.row(
            InlineKeyboardButton("🗑️ 清空热搜", callback_data="hot_search_clear"),
            InlineKeyboardButton("🔄 重置计数", callback_data="hot_search_reset")
        )
        markup.row(InlineKeyboardButton("⬅️ 返回管理员", callback_data="back_to_admin"))
        return markup

    # 创建用户私信键盘
    def create_private_message_keyboard(self):
        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("📝 发送私信", callback_data="pm_send"),
            InlineKeyboardButton("📋 用户列表", callback_data="pm_user_list")
        )
        markup.row(InlineKeyboardButton("⬅️ 返回管理员", callback_data="back_to_admin"))
        return markup

    # 创建日志管理键盘
    def create_log_keyboard(self):
        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("📋 列出所有日志", callback_data="log_list"),
            InlineKeyboardButton("📊 当前日志", callback_data="log_current")
        )
        markup.row(InlineKeyboardButton("⬅️ 返回管理员", callback_data="back_to_admin"))
        return markup

    # 创建用户管理键盘
    def create_user_management_keyboard(self):
        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("📈 用户统计", callback_data="user_stats"),
            InlineKeyboardButton("👤 用户列表", callback_data="user_list")
        )
        markup.row(InlineKeyboardButton("⬅️ 返回管理员", callback_data="back_to_admin"))
        return markup

    # 创建封禁管理键盘
    def create_ban_management_keyboard(self):
        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("🚫 封禁用户", callback_data="ban_user"),
            InlineKeyboardButton("✅ 解封用户", callback_data="unban_user")
        )
        markup.row(InlineKeyboardButton("📋 封禁列表", callback_data="banned_list"))
        markup.row(InlineKeyboardButton("⬅️ 返回管理员", callback_data="back_to_admin"))
        return markup

    # 移除键盘
    def remove_keyboard(self):
        return ReplyKeyboardRemove()

    # 获取数据库信息
    def get_database_info(self):
        if not self.o_database:
            return "❌ 数据库未加载"
        
        db_name = self.o_database.get('name', '未知数据库')
        db_time = self.o_database.get('time', 0)
        db_notes = self.o_database.get('notes', '无备注')
        data_count = len(self.o_database.get('db_data', []))
        
        # 格式化时间
        if db_time:
            formatted_time = timestamp_to_datetime(db_time).strftime('%Y-%m-%d %H:%M:%S')
        else:
            formatted_time = '未知时间'
        
        info = f"""
<b>📊 数据库信息</b>

📁 数据库名称: {db_name}
📅 创建时间: {formatted_time}
📝 数据库备注: {db_notes}
📋 数据条目: {data_count} 条
"""
        return info

    # 初始化代码数据库
    def initDataBase(self):
        try:
            # 读取数据库文件
            with gzip.open(self.DEFAULT_DATABASE_PATH, 'rb') as f:
                final_encrypted_base64 = f.read()
            # 第一步：base64解码
            encrypted_data = base64.b64decode(final_encrypted_base64)
            # 第二步：AES解密
            key = b"vq1ljMB0hRWRKnRDDraM8fE0fLssjWhM"
            cipher = AES.new(key, AES.MODE_ECB)
            # 解密数据
            decrypted_padded_data = cipher.decrypt(encrypted_data)
            # 第三步：去除填充
            try:
                decrypted_data = unpad(decrypted_padded_data, AES.block_size)
            except ValueError as e:
                log_message(f"去除填充时出错: {e}", "ERROR")
                # 如果标准unpad失败，尝试手动处理
                decrypted_data = decrypted_padded_data.rstrip(b'\x00')
            # 第四步：解码base64字符串
            base64_decoded_str = decrypted_data.decode('utf-8')
            json_bytes = base64.b64decode(base64_decoded_str)
            json_str = json_bytes.decode('utf-8')
            # 第五步：解析JSON
            self.o_database = json.loads(json_str)
            # LOG
            log_message(f"已从数据库({self.o_database['name']})中导入了 {len(self.o_database['db_data'])} 条内容。该数据库的创建日期为:{timestamp_to_datetime(self.o_database['time']).strftime('%Y-%m-%d %H:%M:%S')} ({self.o_database['time']}),该数据库的注意事项为:{self.o_database['notes']}", "INFO")
        except Exception as e:
            log_message(f"数据库初始化失败: {e}", "ERROR")
            self.o_database = {"name": "空数据库", "time": 0, "notes": "数据库加载失败", "db_data": []}

    # 生成搜索会话ID
    def generate_search_id(self, user_id, keyword):
        import hashlib
        import time
        unique_str = f"{user_id}_{keyword}_{time.time()}"
        return hashlib.md5(unique_str.encode()).hexdigest()[:8]

    # 处理 /start 命令
    def start_(self, message):
        # 检查用户是否被封禁
        if is_user_banned(message.from_user.id):
            self.bot.send_message(message.chat.id, "❌ 无权限")
            return
        
        log_message(f"用户 {get_user_display_name(message.from_user)}({message.from_user.id}) 发送了 /start 命令", "INFO")
        
        # 更新用户使用记录
        update_user_usage_stats(message.from_user.id, "start")
        
        # 构建完整的欢迎消息（包含数据库信息）
        full_welcome_message = self.WelcomeMessage
        
        # 发送欢迎消息和按钮
        self.bot.send_message(
            message.chat.id, 
            full_welcome_message, 
            parse_mode="HTML",
            reply_markup=self.create_main_keyboard()
        )

    # 显示用户协议
    def ShowUserAgreement_(self, message):
        # 检查用户是否被封禁
        if is_user_banned(message.from_user.id):
            self.bot.send_message(message.chat.id, "❌ 无权限")
            return
        
        self.bot.send_message(
            message.chat.id, 
            self.UserAgreement, 
            parse_mode="HTML",
            reply_markup=self.create_main_keyboard()
        )
    
    # 搜索功能 - 带分页
    def handle_search(self, message, keyword=None):
        # 检查用户是否被封禁
        if is_user_banned(message.from_user.id):
            self.bot.send_message(message.chat.id, "❌ 无权限")
            return
        
        if not self.o_database or not self.o_database.get("db_data"):
            self.bot.reply_to(message, "❌ 数据库未加载或为空")
            return
        
        user_id = message.from_user.id
        
        # 检查搜索限制
        can_search, limit_message = self.check_search_limit(user_id)
        if not can_search:
            self.bot.reply_to(message, limit_message)
            return
        
        # 如果没有提供关键词，从消息中提取
        if keyword is None:
            if message.text.startswith("搜索 "):
                keyword = message.text[3:].strip()
            else:
                keyword = message.text.strip()
        
        if not keyword:
            self.bot.send_message(
                message.chat.id,
                "🔍 请输入搜索关键词\n\n格式：<code>搜索 关键词</code>\n或直接发送关键词",
                parse_mode="HTML",
                reply_markup=self.create_main_keyboard()
            )
            return
        
        # 检查关键词是否包含广告内容
        contains_ad = contains_advertisement(keyword)
        
        if contains_ad:
            # 发送警告给所有管理员
            user_nickname = get_user_display_name(message.from_user)
            warning_msg = f"🚨 广告链接检测\n用户ID: {message.from_user.id}\n昵称: {user_nickname}\n搜索内容: {keyword}"
            
            # 发送警告给所有管理员
            for admin_id in self.ADMIN_IDS:
                try:
                    self.bot.send_message(admin_id, warning_msg)
                except Exception as e:
                    log_message(f"向管理员 {admin_id} 发送警告失败: {e}", "ERROR")
            
            # 不更新热搜计数（广告内容不计入热搜）
            log_message(f"用户 {user_id} 搜索广告内容: {keyword}，不计入热搜", "AD_DETECT")
        else:
            # 只有非广告内容才更新热搜计数
            update_hot_search_count(keyword)
        
        # 更新用户使用记录（无论是否广告都记录）
        update_user_usage_stats(user_id, "search", keyword)
        
        # 执行搜索（无论是否广告都返回结果）
        results = search_in_descriptions(self.o_database, keyword)
        
        if not results:
            self.bot.send_message(
                message.chat.id,
                f"🔍 没有找到包含「{keyword}」的代码介绍",
                parse_mode='HTML',
                reply_markup=self.create_main_keyboard()
            )
            return
        
        # 生成搜索会话ID
        search_id = self.generate_search_id(user_id, keyword)
        
        # 存储搜索会话
        self.user_search_sessions[search_id] = {
            'user_id': user_id,
            'keyword': keyword,
            'results': results,
            'current_page': 1,
            'total_pages': len(results),
            'created_time': datetime.datetime.now(),
            'contains_ad': contains_ad  # 标记是否包含广告
        }
        
        # LOG
        if contains_ad:
            log_message(f"用户 {get_user_display_name(message.from_user)}({user_id}) 搜索广告关键词: {keyword}, 找到 {len(results)} 条结果（不计入热搜）", "INFO")
        else:
            log_message(f"用户 {get_user_display_name(message.from_user)}({user_id}) 搜索关键词: {keyword}, 找到 {len(results)} 条结果", "INFO")
        
        # 显示第一页
        self.show_search_page(message.chat.id, search_id, 1, message.message_id)
        
        # 显示限制提示信息
        if limit_message:
            self.bot.send_message(message.chat.id, limit_message)

    # 显示搜索结果的指定页面
    def show_search_page(self, chat_id, search_id, page_number, reply_to_message_id=None):
        if search_id not in self.user_search_sessions:
            self.bot.send_message(chat_id, "❌ 搜索会话已过期，请重新搜索")
            return
        
        session = self.user_search_sessions[search_id]
        results = session['results']
        total_pages = len(results)
        user_id = session['user_id']
        contains_ad = session.get('contains_ad', False)
        
        # 检查翻页限制（非VIP用户最多6页）
        if not self.check_page_limit(user_id, page_number):
            self.bot.send_message(chat_id, "❌ 非VIP用户最多查看6页内容\n\n⭐ 升级VIP可查看全部结果！")
            page_number = 6  # 限制在6页
        
        # 确保页码在有效范围内
        page_number = max(1, min(page_number, total_pages))
        session['current_page'] = page_number
        
        # 获取当前页的数据
        current_item = results[page_number - 1]
        code, code_type, description = current_item
        
        # 代码种类映射
        type_names = {
            0: "未知",
            1: "推荐使用 @ShowFilesBot 必要时使用 @FilesPan1Bot (FilesDriveBLGA与旧密文)",
            2: "@ShowFilesBot 或 @MediaBKbot", 
            3: "@ShowFilesBot",
            4: "@ShowFilesBot (DataPanBot)",
            5: "@ShowFilesBot (FilesPan1Bot)",
            6: "南天门解码器( @ntmjmqbot )"
        }
        type_name = type_names.get(code_type)
        
        # 构建消息内容
        response = f"🔍 <b>搜索「{session['keyword']}」</b>\n"
        
        # 如果是广告内容，添加提示
        if contains_ad:
            response += "⚠️ <i>检测到广告内容，本次搜索不计入热搜榜单</i>\n"
        
        response += f"📄 <i>第 {page_number}/{total_pages} 页</i>\n"
        
        # 显示翻页限制提示
        if not self.is_vip_user(user_id) and total_pages > 6:
            response += f"<i>💡 非VIP用户最多查看6页内容</i>\n\n"
        else:
            response += "\n"
        
        response += f"<b>📁 代码适用解码器:</b> {type_name}\n"
        response += f"<b>🔤 代码内容:</b>\n<code>{code}</code>\n\n"
        response += f"<b>📝 代码介绍:</b>\n<i>{description}</i>\n\n"
        
        # 添加广告
        user_ads = self.get_user_ads(user_id, int(self.MAX_ADS_DISPLAY))
        if user_ads:
            response += self.format_ads_message(user_ads)
        
        # 添加底部标识
        response += f"\n🌟 <i>UU搜索 - UUSearchBot</i> 🌟"

        # 创建分页键盘
        markup = self.create_pagination_keyboard(page_number, total_pages, search_id)
        
        # 发送或编辑消息
        if reply_to_message_id:
            # 编辑现有消息
            try:
                self.bot.edit_message_text(
                    response,
                    chat_id,
                    reply_to_message_id,
                    parse_mode='HTML',
                    reply_markup=markup,
                    disable_web_page_preview=True
                )
            except Exception as e:
                # 如果编辑失败，发送新消息
                log_message(f"编辑消息失败: {e}", "ERROR")
                self.bot.send_message(
                    chat_id,
                    response,
                    parse_mode='HTML',
                    reply_markup=markup
                )
        else:
            # 发送新消息
            self.bot.send_message(
                chat_id,
                response,
                parse_mode='HTML',
                reply_markup=markup
            )
    # 显示VIP购买选项
    def show_vip_purchase_options(self, message):
        vip_options = VIP_PRICE_LIST
        vip_options = vip_options + f"🆔 <b>您的用户ID是： </b><code>{message.from_user.id}</code>开通VIP需要告诉我你的ID"
        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("📊 VIP状态", callback_data="vip_status"),
            InlineKeyboardButton("⬅️ 返回上一页", callback_data="vip_back")
        )
        try:
            # 先尝试删除原消息（如果存在）
            if hasattr(message, 'message_id'):
                try:
                    self.bot.delete_message(message.chat.id, message.message_id)
                except:
                    pass  # 如果删除失败，继续发送新消息
            
            # 总是发送新消息
            self.bot.send_message(
                message.chat.id,
                vip_options,
                parse_mode='HTML',
                reply_markup=markup
            )
            
        except Exception as e:
            log_message(f"显示VIP购买选项失败: {e}", "ERROR")
            # 即使失败也尝试发送基本消息
            try:
                self.bot.send_message(
                    message.chat.id,
                    "⭐ VIP服务 - 联系 @JLmn7 购买VIP",
                    reply_markup=markup
                )
            except:
                pass
    # 处理分页回调
    def handle_pagination_callback(self, call):
        try:
            data = call.data
            message = call.message
            
            if data.startswith("page_"):
                # 解析页码信息
                parts = data.split("_")
                if len(parts) >= 3:
                    search_id = parts[1]
                    page_number = int(parts[2])
                    
                    # 编辑现有消息显示指定页面
                    self.show_search_page(call.message.chat.id, search_id, page_number, call.message.message_id)
                    
                    # 回答回调查询
                    self.bot.answer_callback_query(call.id, f"切换到第 {page_number} 页")
            
            elif data.startswith("jump_"):
                # 跳转到指定页面
                search_id = data.split("_")[1]
                # 请求用户输入页码
                msg = self.bot.send_message(
                    call.message.chat.id,
                    "🔢 请输入要跳转的页码：",
                    reply_to_message_id=call.message.message_id
                )
                # 注册下一步处理器
                self.bot.register_next_step_handler(msg, self.handle_jump_page, search_id)
                self.bot.answer_callback_query(call.id, "请输入页码")
            
            elif data == "new_search":
                # 重新搜索
                self.bot.delete_message(call.message.chat.id, call.message.message_id)
                self.bot.send_message(
                    call.message.chat.id,
                    "🔍 请输入新的搜索关键词：",
                    parse_mode="HTML",
                    reply_markup=self.create_main_keyboard()
                )
                self.bot.answer_callback_query(call.id, "开始新的搜索")
            
            elif data == "back_to_main":
                # 返回主页
                self.bot.delete_message(call.message.chat.id, call.message.message_id)
                # 创建临时消息对象用于start_函数
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                self.start_(temp_message)
                self.bot.answer_callback_query(call.id, "返回主页")
            
            elif data == "page_info":
                self.bot.answer_callback_query(call.id, "当前页面信息")
            
            # VIP相关回调
            elif data == "vip_buy":
                # 直接调用VIP购买选项方法
                self.show_vip_purchase_options(call.message)
                self.bot.answer_callback_query(call.id, "VIP购买选项")
                
            elif data == "vip_status":
                # 创建临时消息对象
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                self.show_vip_status(temp_message)
                self.bot.answer_callback_query(call.id, "VIP状态")
                
            elif data == "vip_back":
                # 创建临时消息对象
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                self.handle_vip_service(temp_message)
                self.bot.answer_callback_query(call.id, "返回VIP服务")
            
            # 日志管理回调
            elif data == "log_list":
                # 创建临时消息对象，包含正确的用户信息
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                self.list_log_files(temp_message)
                self.bot.answer_callback_query(call.id, "列出日志文件")
                
            elif data == "log_current":
                # 创建临时消息对象，包含正确的用户信息
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                self.send_current_log(temp_message)
                self.bot.answer_callback_query(call.id, "发送当前日志")
                
            elif data == "back_to_admin":
                # 创建临时消息对象，包含正确的用户信息
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                self.handle_admin_command(temp_message)
                self.bot.answer_callback_query(call.id, "返回管理员")
            
            # 用户管理回调
            elif data == "user_stats":
                # 创建临时消息对象，包含正确的用户信息
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                self.show_user_statistics(temp_message)
                self.bot.answer_callback_query(call.id, "用户统计")
                
            elif data == "user_list":
                # 创建临时消息对象，包含正确的用户信息
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                self.show_user_list(temp_message)
                self.bot.answer_callback_query(call.id, "用户列表")
            
            # 封禁管理回调
            elif data == "ban_user":
                # 创建临时消息对象，包含正确的用户信息
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                self.request_ban_user(temp_message)
                self.bot.answer_callback_query(call.id, "封禁用户")
                
            elif data == "unban_user":
                # 创建临时消息对象，包含正确的用户信息
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                self.request_unban_user(temp_message)
                self.bot.answer_callback_query(call.id, "解封用户")
                
            elif data == "banned_list":
                # 创建临时消息对象，包含正确的用户信息
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                self.show_banned_users(temp_message)
                self.bot.answer_callback_query(call.id, "封禁列表")
            
            # 热搜榜单管理回调
            elif data == "hot_search_view":
                # 创建临时消息对象，包含正确的用户信息
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                self.show_hot_search_list(temp_message)
                self.bot.answer_callback_query(call.id, "查看热搜榜单")
                
            elif data == "hot_search_edit":
                # 创建临时消息对象，包含正确的用户信息
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                self.request_edit_hot_search(temp_message)
                self.bot.answer_callback_query(call.id, "修改热搜榜单")
                
            elif data == "hot_search_clear":
                # 创建临时消息对象，包含正确的用户信息
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                self.clear_hot_searches(temp_message)
                self.bot.answer_callback_query(call.id, "清空热搜榜单")
                
            elif data == "hot_search_reset":
                # 创建临时消息对象，包含正确的用户信息
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                self.reset_hot_search_counts(temp_message)
                self.bot.answer_callback_query(call.id, "重置搜索计数")
            
            # 数据导出回调
            elif data in ["export_users", "export_vip", "export_hot_searches", "export_search_stats", "export_banned", "export_full"]:
                # 删除原消息
                try:
                    self.bot.delete_message(call.message.chat.id, call.message.message_id)
                except:
                    pass
                
                # 发送处理中消息
                processing_msg = self.bot.send_message(
                    call.message.chat.id,
                    "📤 <b>正在打包数据文件...</b>",
                    parse_mode='HTML'
                )
                
                # 创建临时消息对象
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                
                # 直接导出所有数据
                self.export_all_data(temp_message)
                
                # 删除处理中消息
                try:
                    self.bot.delete_message(call.message.chat.id, processing_msg.message_id)
                except:
                    pass
                
                self.bot.answer_callback_query(call.id, "数据导出完成")
            
            # 用户私信回调
            elif data == "pm_send":
                # 创建临时消息对象，包含正确的用户信息
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                self.request_private_message(temp_message)
                self.bot.answer_callback_query(call.id, "发送私信")
                
            elif data == "pm_user_list":
                # 创建临时消息对象，包含正确的用户信息
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                self.show_pm_user_list(temp_message)
                self.bot.answer_callback_query(call.id, "用户列表")
            
            # 广播消息按钮回调
            elif data.startswith("broadcast_type_"):
                self.handle_broadcast_type_callback(call)
                
            elif data == "broadcast_confirm":
                self.handle_broadcast_confirm(call)

            elif data == "broadcast_cancel":
                self.handle_broadcast_cancel(call)

            elif data == "broadcast_edit":
                self.handle_broadcast_edit(call)

            # 广告管理回调
            elif data == "ad_list":
                self.show_ad_list(call)
            elif data == "ad_add":
                self.request_add_ad(call)
            elif data == "ad_enable":
                self.enable_ads(call)
            elif data == "ad_disable":
                self.disable_ads(call)
            elif data == "ad_stats":
                self.show_ad_stats(call)
            elif data == "ad_delete":
                self.request_delete_ad(call)
                
        except Exception as e:
            log_message(f"处理分页回调时出错: {e}", "ERROR")
            self.bot.answer_callback_query(call.id, "操作失败，请重试")

    # 显示广告列表
    def show_ad_list(self, call):
        try:
            ads_data = load_advertisements()
            ads_list = "📋 <b>广告列表</b>\n\n"
            
            for ad in ads_data.get("ads", []):
                status = "✅" if ad.get("enabled", True) else "❌"
                ads_list += f"{status} <b>ID{ad['id']}:</b> {ad['text']}\n"
                ads_list += f"   🔗 {ad['url']}\n"
                ads_list += f"   👁️ {ad.get('impressions', 0)} | 👆 {ad.get('clicks', 0)}\n\n"
            
            self.bot.edit_message_text(
                ads_list,
                call.message.chat.id,
                call.message.message_id,
                parse_mode='HTML'
            )
        except Exception as e:
            log_message(f"显示广告列表失败: {e}", "ERROR")
            self.bot.answer_callback_query(call.id, "显示失败")

    # 请求添加广告
    def request_add_ad(self, call):
        try:
            msg = self.bot.send_message(
                call.message.chat.id,
                "➕ <b>添加广告</b>\n\n请按以下格式发送广告信息：\n\n<code>广告文字 - 广告链接</code>\n\n示例：\n<code>加入VIP享受无广告体验 - https://t.me/your_bot</code>",
                parse_mode='HTML'
            )
            self.bot.register_next_step_handler(msg, self.handle_add_ad)
            self.bot.answer_callback_query(call.id, "请发送广告信息")
        except Exception as e:
            log_message(f"请求添加广告失败: {e}", "ERROR")
            self.bot.answer_callback_query(call.id, "操作失败")

    # 处理添加广告
    def handle_add_ad(self, message):
        try:
            if ' - ' not in message.text:
                self.bot.reply_to(message, "❌ 格式错误，请使用：广告文字 - 广告链接")
                return
            
            text, url = message.text.split(' - ', 1)
            text = text.strip()
            url = url.strip()
            
            ads_data = load_advertisements()
            if not ads_data:
                self.bot.reply_to(message, "❌ 加载广告数据失败")
                return
            
            new_ad = {
                "id": len(ads_data["ads"]) + 1,
                "text": text,
                "url": url,
                "enabled": True,
                "clicks": 0,
                "impressions": 0,
                "created_time": datetime.datetime.now().isoformat()
            }
            
            ads_data["ads"].append(new_ad)
            
            if save_advertisements(ads_data):
                self.bot.reply_to(message, f"✅ 广告添加成功！\n\n📝 {text}\n🔗 {url}")
            else:
                self.bot.reply_to(message, "❌ 保存广告失败")
                
        except Exception as e:
            log_message(f"添加广告失败: {e}", "ERROR")
            self.bot.reply_to(message, f"❌ 添加广告失败: {e}")

    # 启用所有广告
    def enable_ads(self, call):
        try:
            ads_data = load_advertisements()
            ads_data["enabled"] = True
            
            if save_advertisements(ads_data):
                self.bot.edit_message_text(
                    "✅ 广告已启用",
                    call.message.chat.id,
                    call.message.message_id
                )
            else:
                self.bot.answer_callback_query(call.id, "启用失败")
        except Exception as e:
            log_message(f"启用广告失败: {e}", "ERROR")
            self.bot.answer_callback_query(call.id, "操作失败")

    # 禁用所有广告
    def disable_ads(self, call):
        try:
            ads_data = load_advertisements()
            ads_data["enabled"] = False
            
            if save_advertisements(ads_data):
                self.bot.edit_message_text(
                    "❌ 广告已禁用",
                    call.message.chat.id,
                    call.message.message_id
                )
            else:
                self.bot.answer_callback_query(call.id, "禁用失败")
        except Exception as e:
            log_message(f"禁用广告失败: {e}", "ERROR")
            self.bot.answer_callback_query(call.id, "操作失败")

    # 显示广告统计
    def show_ad_stats(self, call):
        try:
            ads_data = load_advertisements()
            total_impressions = sum(ad.get('impressions', 0) for ad in ads_data.get('ads', []))
            total_clicks = sum(ad.get('clicks', 0) for ad in ads_data.get('ads', []))
            ctr = (total_clicks / total_impressions * 100) if total_impressions > 0 else 0
            
            stats_text = f"""
<b>📊 广告统计</b>

总展示次数: {total_impressions}
总点击次数: {total_clicks}
点击率: {ctr:.2f}%

<b>各广告表现：</b>
"""
            for ad in ads_data.get('ads', []):
                ad_ctr = (ad.get('clicks', 0) / ad.get('impressions', 0) * 100) if ad.get('impressions', 0) > 0 else 0
                status = "✅" if ad.get('enabled', True) else "❌"
                stats_text += f"\n{status} <b>{ad['text']}</b>\n"
                stats_text += f"👁️ {ad.get('impressions', 0)} | 👆 {ad.get('clicks', 0)} | 📊 {ad_ctr:.2f}%\n"
            
            self.bot.edit_message_text(
                stats_text,
                call.message.chat.id,
                call.message.message_id,
                parse_mode='HTML'
            )
        except Exception as e:
            log_message(f"显示广告统计失败: {e}", "ERROR")
            self.bot.answer_callback_query(call.id, "显示失败")

    # 请求删除广告
    def request_delete_ad(self, call):
        try:
            ads_data = load_advertisements()
            ads_list = "🗑️ <b>删除广告</b>\n\n回复广告ID进行删除：\n\n"
            
            for ad in ads_data.get("ads", []):
                ads_list += f"<code>{ad['id']}</code> - {ad['text']}\n"
            
            msg = self.bot.send_message(
                call.message.chat.id,
                ads_list,
                parse_mode='HTML'
            )
            self.bot.register_next_step_handler(msg, self.handle_delete_ad)
            self.bot.answer_callback_query(call.id, "请回复广告ID")
        except Exception as e:
            log_message(f"请求删除广告失败: {e}", "ERROR")
            self.bot.answer_callback_query(call.id, "操作失败")

    # 处理删除广告
    def handle_delete_ad(self, message):
        try:
            ad_id = int(message.text.strip())
            ads_data = load_advertisements()
            
            # 查找并删除广告
            ads_data["ads"] = [ad for ad in ads_data.get("ads", []) if ad.get("id") != ad_id]
            
            if save_advertisements(ads_data):
                self.bot.reply_to(message, f"✅ 广告 ID{ad_id} 已删除")
            else:
                self.bot.reply_to(message, "❌ 删除广告失败")
                
        except ValueError:
            self.bot.reply_to(message, "❌ 请输入有效的广告ID数字")
        except Exception as e:
            log_message(f"删除广告失败: {e}", "ERROR")
            self.bot.reply_to(message, f"❌ 删除广告失败: {e}")

    # 专门的广播类型回调处理
    def handle_broadcast_type_callback(self, call):
        try:
            data = call.data
            
            if data == "broadcast_cancel":
                # 处理取消发送
                self.handle_broadcast_cancel(call)
                return
                
            broadcast_type = data.replace("broadcast_type_", "")
            
            type_messages = {
                "text": "📝 请发送纯文本广播内容：",
                "html": "🎨 请发送HTML格式广播内容（支持HTML标签）：",
                "photo": "🖼️ 请发送图片：",
                "document": "📎 请发送文件：",
                "buttons": "🔘 请发送广播文本内容（稍后配置按钮）：",
                "photo_buttons": "🖼️ 请先发送图片："
            }
            
            if broadcast_type in type_messages:
                # 初始化广播会话
                if not hasattr(self, 'broadcast_sessions'):
                    self.broadcast_sessions = {}
                
                self.broadcast_sessions[call.from_user.id] = {
                    'type': broadcast_type,
                    'step': 'waiting_content',
                    'confirmed': False
                }
                
                # 删除原消息并发送新消息
                try:
                    self.bot.delete_message(call.message.chat.id, call.message.message_id)
                except:
                    pass
                
                self.bot.send_message(
                    call.message.chat.id,
                    type_messages[broadcast_type],
                    parse_mode='HTML'
                )
            
            self.bot.answer_callback_query(call.id, "请发送广播内容")
            
        except Exception as e:
            log_message(f"处理广播类型回调失败: {e}", "ERROR")
            self.bot.answer_callback_query(call.id, "操作失败")

    # 处理跳转页面输入
    def handle_jump_page(self, message, search_id):
        try:
            page_number = int(message.text.strip())
            # 删除用户输入的消息
            self.bot.delete_message(message.chat.id, message.message_id)
            # 跳转到指定页面，使用当前消息的ID
            self.show_search_page(message.chat.id, search_id, page_number, message.message_id)
        except ValueError:
            self.bot.send_message(message.chat.id, "❌ 请输入有效的页码数字")
        except Exception as e:
            log_message(f"处理跳转页面失败: {e}", "ERROR")
            self.bot.send_message(message.chat.id, "❌ 跳转失败，请重试")

    # 显示VIP购买选项
    def handle_vip_service(self, message):
        vip_options = VIP_PRICE_LIST
        vip_options = vip_options + f"🆔 <b>您的用户ID是： </b><code>{message.from_user.id}</code>开通VIP需要告诉我你的ID"
        
        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("💰 购买VIP", url = GO_BUY_URL),
            InlineKeyboardButton("📊 VIP状态", callback_data="vip_status")
        )
        
        try:
            # 如果有message_id（来自回调），尝试删除原消息
            if hasattr(message, 'message_id'):
                try:
                    self.bot.delete_message(message.chat.id, message.message_id)
                except:
                    pass  # 删除失败也没关系
            
            # 发送新消息
            self.bot.send_message(
                message.chat.id,
                vip_options,
                parse_mode='HTML',
                reply_markup=markup
            )
        except Exception as e:
            log_message(f"显示VIP服务失败: {e}", "ERROR")
            # 备用方案
            self.bot.send_message(
                message.chat.id,
                "⭐ VIP服务 - 联系 @JLmn7 购买VIP",
                reply_markup=markup
            )

    # 显示VIP状态
    def show_vip_status(self, message):
        user_id = message.from_user.id
        is_vip = self.is_vip_user(user_id)
        remaining_time = self.get_vip_remaining_time(user_id)
        
        if is_vip:
            status_text = f"""
    <b>⭐ 您的VIP状态</b>

    ✅ <b>状态：</b> VIP会员
    ⏰ <b>剩余时间：</b> {remaining_time}
    🎉 <b>享受所有VIP特权！</b>
    """
        else:
            status_text = f"""
    <b>⭐ 您的VIP状态</b>

    ❌ <b>状态：</b> 非VIP会员
    🆔 <b>您的用户ID：</b> <code>{user_id}</code>

    📊 <b>当前限制：</b>
    • 每天最多搜索10次
    • 最多查看6页结果

    💡 <b>升级VIP享受：</b>
    • 无限制搜索次数
    • 查看全部搜索结果
    • 优先技术支持
    """
        
        markup = InlineKeyboardMarkup()
        if not is_vip:
            markup.row(InlineKeyboardButton("💰 联系购买", url = GO_BUY_URL))  # 非VIP用户显示购买按钮
        markup.row(InlineKeyboardButton("⬅️ 返回上一页", callback_data="vip_back"))
        
        try:
            # 检查是否有message_id（来自回调）
            if hasattr(message, 'message_id'):
                self.bot.edit_message_text(
                    status_text,
                    message.chat.id,
                    message.message_id,
                    parse_mode='HTML',
                    reply_markup=markup
                )
            else:
                # 来自普通消息
                self.bot.send_message(
                    message.chat.id,
                    status_text,
                    parse_mode='HTML',
                    reply_markup=markup
                )
        except Exception as e:
            log_message(f"显示VIP状态失败: {e}", "ERROR")
            self.bot.send_message(
                message.chat.id,
                status_text,
                parse_mode='HTML',
                reply_markup=markup
            )
    
    # 全库随机功能
    def handle_random_search(self, message):
        # 检查用户是否被封禁
        if is_user_banned(message.from_user.id):
            self.bot.send_message(message.chat.id, "❌ 无权限")
            return
        
        if not self.o_database or not self.o_database.get("db_data"):
            self.bot.reply_to(message, "❌ 数据库未加载或为空")
            return
        
        user_id = message.from_user.id
        
        # 检查随机限制
        can_random, limit_message = self.check_random_limit(user_id)
        if not can_random:
            self.bot.reply_to(message, limit_message)
            return
        
        # 从数据库中随机选择一条记录
        random_item = random.choice(self.o_database["db_data"])
        code, code_type, description = random_item
        
        # 代码种类映射
        type_names = {
            1: "推荐使用 @ShowFilesBot 必要时使用 @FilesPan1Bot (FilesDriveBLGA与旧密文)",
            2: "@ShowFilesBot 或 @MediaBKbot", 
            3: "@ShowFilesBot",
            4: "@ShowFilesBot (DataPanBot)",
            5: "@ShowFilesBot (FilesPan1Bot)",
            6: "南天门解码器( @ntmjmqbot )"
        }
        type_name = type_names.get(code_type)
        
        # 构建消息内容
        response = f"🎲 <b>全库随机推荐</b>\n\n"
        
        # 显示随机次数提示
        user_id_str = str(user_id)
        today_randoms = self.user_random_counts.get(user_id_str, 0)
        remaining_randoms = MAX_RANDOM_PER_DAY_NON_VIP - today_randoms
        
        if not self.is_vip_user(user_id):
            response += f"<i>💡 今日剩余随机次数：{remaining_randoms}/{MAX_RANDOM_PER_DAY_NON_VIP}</i>\n\n"
        
        response += f"<b>📁 代码适用解码器:</b> {type_name}\n"
        response += f"<b>🔤 代码内容:</b>\n<code>{code}</code>\n\n"
        response += f"<b>📝 代码介绍:</b>\n<i>{description}</i>\n\n"

        # 添加广告
        user_ads = self.get_user_ads(user_id, int(self.MAX_ADS_DISPLAY))
        if user_ads:
            response += self.format_ads_message(user_ads)
        
        # 添加署名
        response += f"\n<i>UU搜索 - UUSearchBot</i>"
        
        # 更新用户使用记录
        update_user_usage_stats(user_id, "random_search")
        
        # 发送随机结果
        self.bot.send_message(
            message.chat.id,
            response,
            parse_mode='HTML',
            reply_markup=self.create_main_keyboard(),
            disable_web_page_preview=True
        )
        
        # 显示限制提示信息
        if limit_message:
            self.bot.send_message(message.chat.id, limit_message)
    
    # 显示热搜榜单
    def handle_hot_searches(self, message):
        # 检查用户是否被封禁
        if is_user_banned(message.from_user.id):
            self.bot.send_message(message.chat.id, "❌ 无权限")
            return
        
        top_searches = get_top_hot_searches(10)
        
        if not top_searches:
            self.bot.send_message(
                message.chat.id,
                "🔥 <b>热搜榜单</b>\n\n暂无搜索数据",
                parse_mode='HTML',
                reply_markup=self.create_main_keyboard()
            )
            return
        
        # 构建热搜榜单消息
        hot_searches_text = "🔥 <b>热搜榜单 TOP 10</b>\n\n"
        
        for i, (keyword, count) in enumerate(top_searches, 1):
            hot_searches_text += f"{i}. <code>{keyword}</code> - {count}次\n"
        
        hot_searches_text += f"\n💡 点击热搜关键词可直接搜索"
        
        self.bot.send_message(
            message.chat.id,
            hot_searches_text,
            parse_mode='HTML',
            reply_markup=self.create_main_keyboard()
        )
    
    # 管理员命令处理
    def handle_admin_command(self, message):
        if message.from_user.id not in self.ADMIN_IDS:
            self.bot.reply_to(message, "❌ 无权访问管理员功能")
            return
        
        admin_menu = """
    <b>⚙️ 管理员面板</b>

    选择要管理的功能：
    """
        admin_menu = admin_menu + "\n\n" + self.get_database_info()
        
        try:
            self.bot.send_message(
                message.chat.id,
                admin_menu,
                parse_mode='HTML',
                reply_markup=self.create_admin_keyboard()
            )
        except Exception as e:
            self.bot.reply_to(message, f"❌ 发送管理员面板失败: {e}")
    
    # 处理管理员功能
    def handle_admin_functions(self, message):
        if message.from_user.id not in self.ADMIN_IDS:
            return
        
        if message.text == "📊 统计信息":
            self.show_admin_stats(message)
        elif message.text == "👥 用户管理":
            self.show_user_management(message)
        elif message.text == "⭐ VIP管理":
            self.show_vip_management(message)
        elif message.text == "📁 日志管理":
            self.show_log_management(message)
        elif message.text == "🔄 重置限制":
            self.reset_user_limits(message)
        elif message.text == "📢 广播消息":
            self.request_broadcast_message(message)
        elif message.text == "🚫 封禁管理":
            self.show_ban_management(message)
        elif message.text == "🔥 热搜榜单管理":
            self.show_hot_search_management(message)
        elif message.text == "📤 数据导出":
            self.show_data_export_options(message)
        elif message.text == "💬 用户私信":
            self.show_private_message_options(message)
        elif message.text == "📢 广告管理":
            self.show_ad_management(message)
        elif message.text == "🏠 返回主菜单":
            self.start_(message)

    # 显示广告管理
    def show_ad_management(self, message):
        ads_data = load_advertisements()
        enabled_status = "✅ 启用" if ads_data.get("enabled", True) else "❌ 禁用"
        ad_count = len([ad for ad in ads_data.get("ads", []) if ad.get("enabled", True)])
        
        ad_management_text = f"""
<b>📢 广告管理</b>

当前状态: {enabled_status}
启用广告数: {ad_count} 条

选择管理操作：
"""
        self.bot.send_message(
            message.chat.id,
            ad_management_text,
            parse_mode='HTML',
            reply_markup=self.create_ad_management_keyboard()
        )
    
    # 显示管理员统计信息
    def show_admin_stats(self, message):
        total_vip = len(self.vip_users)
        today_searches = sum(self.user_search_counts.values())
        active_sessions = len(self.user_search_sessions)
        user_stats = load_user_usage_stats()
        total_users = len(user_stats)
        banned_users = load_banned_users()
        total_banned = len(banned_users)
        
        stats_text = f"""
<b>📊 系统统计信息</b>

⭐ VIP用户数: {total_vip}
🔍 今日搜索次数: {today_searches}
💬 活跃会话数: {active_sessions}
👥 总用户数: {total_users}
🚫 封禁用户: {total_banned}
📁 数据库条目: {len(self.o_database.get('db_data', []))}
"""
        self.bot.send_message(message.chat.id, stats_text, parse_mode='HTML')
    
    # 显示用户管理
    def show_user_management(self, message):
        user_management = """
<b>👥 用户管理</b>

选择用户管理操作：
"""
        self.bot.send_message(
            message.chat.id,
            user_management,
            parse_mode='HTML',
            reply_markup=self.create_user_management_keyboard()
        )
    
    # 显示用户统计信息
    def show_user_statistics(self, message):
        user_stats = load_user_usage_stats()
        total_users = len(user_stats)
        
        # 计算活跃用户（最近7天有活动的）
        seven_days_ago = datetime.datetime.now() - datetime.timedelta(days=7)
        active_users = 0
        total_searches = 0
        
        for user_id, stats in user_stats.items():
            total_searches += stats.get('total_searches', 0)
            last_active = datetime.datetime.fromisoformat(stats.get('last_active', '2000-01-01'))
            if last_active > seven_days_ago:
                active_users += 1
        
        # 获取搜索最多的用户
        top_searchers = sorted(
            [(uid, stats.get('total_searches', 0)) for uid, stats in user_stats.items()],
            key=lambda x: x[1],
            reverse=True
        )[:5]
        
        stats_text = f"""
<b>📈 用户统计信息</b>

👥 总用户数: {total_users}
🔍 总搜索次数: {total_searches}
📊 活跃用户(7天): {active_users}
⭐ VIP用户: {len(self.vip_users)}

🏆 <b>搜索排行榜 TOP 5:</b>
"""
        
        for i, (user_id, searches) in enumerate(top_searchers, 1):
            stats_text += f"{i}. 用户 {user_id} - {searches}次\n"
        
        self.bot.send_message(message.chat.id, stats_text, parse_mode='HTML')
    
    # 显示用户列表
    def show_user_list(self, message):
        user_stats = load_user_usage_stats()
        total_users = len(user_stats)
        
        # 按最后活跃时间排序
        sorted_users = sorted(
            user_stats.items(),
            key=lambda x: datetime.datetime.fromisoformat(x[1].get('last_active', '2000-01-01')),
            reverse=True
        )[:20]  # 只显示前20个用户
        
        user_list_text = f"""
<b>👤 用户列表 (最近活跃的前20个)</b>

总用户数: {total_users}

"""
        
        for i, (user_id, stats) in enumerate(sorted_users, 1):
            last_active = datetime.datetime.fromisoformat(stats.get('last_active', '2000-01-01'))
            days_ago = (datetime.datetime.now() - last_active).days
            vip_status = "⭐" if self.is_vip_user(int(user_id)) else "🔹"
            banned_status = "🚫" if is_user_banned(int(user_id)) else "✅"
            
            user_list_text += f"{i}. {vip_status}{banned_status} 用户 {user_id}\n"
            user_list_text += f"   搜索: {stats.get('total_searches', 0)}次 | {days_ago}天前活跃\n"
        
        if total_users > 20:
            user_list_text += f"\n... 还有 {total_users - 20} 个用户未显示"
        
        self.bot.send_message(message.chat.id, user_list_text, parse_mode='HTML')
    
    # 显示VIP管理
    def show_vip_management(self, message):
        vip_count = len(self.vip_users)
        vip_list = "\n".join([f"• {user_id}" for user_id in list(self.vip_users.keys())[:10]])
        if len(self.vip_users) > 10:
            vip_list += f"\n• ... 还有 {len(self.vip_users) - 10} 个用户"
        
        vip_management = f"""
<b>⭐ VIP用户管理</b>

当前VIP用户数: {vip_count}

{vip_list if vip_list else "暂无VIP用户"}

发送 <code>/vip 用户ID 天数</code> 添加VIP
发送 <code>/unvip 用户ID</code> 移除VIP
"""
        self.bot.send_message(message.chat.id, vip_management, parse_mode='HTML')
    
    # 显示日志管理
    def show_log_management(self, message):
        log_management = """
<b>📁 日志管理</b>

选择日志管理操作：
"""
        self.bot.send_message(
            message.chat.id,
            log_management,
            parse_mode='HTML',
            reply_markup=self.create_log_keyboard()
        )
    
    # 显示封禁管理
    def show_ban_management(self, message):
        ban_management = """
<b>🚫 封禁管理</b>

选择封禁管理操作：
"""
        self.bot.send_message(
            message.chat.id,
            ban_management,
            parse_mode='HTML',
            reply_markup=self.create_ban_management_keyboard()
        )
    
    # 请求封禁用户
    def request_ban_user(self, message):
        msg = self.bot.send_message(
            message.chat.id,
            "🚫 请输入要封禁的用户ID和原因（用空格分隔）：\n\n示例：<code>123456789 发布违规内容</code>",
            parse_mode='HTML'
        )
        self.bot.register_next_step_handler(msg, self.handle_ban_user)
    
    # 处理封禁用户
    def handle_ban_user(self, message):
        try:
            parts = message.text.split(' ', 1)
            if len(parts) < 2:
                self.bot.reply_to(message, "❌ 格式错误，请提供用户ID和原因")
                return
            
            user_id = int(parts[0])
            reason = parts[1]
            
            if ban_user(user_id, reason, message.from_user.id):
                self.bot.reply_to(message, f"✅ 用户 {user_id} 已被封禁\n原因: {reason}")
            else:
                self.bot.reply_to(message, f"❌ 封禁用户 {user_id} 失败")
                
        except ValueError:
            self.bot.reply_to(message, "❌ 用户ID必须是数字")
        except Exception as e:
            self.bot.reply_to(message, f"❌ 封禁用户失败: {e}")
    
    # 请求解封用户
    def request_unban_user(self, message):
        msg = self.bot.send_message(
            message.chat.id,
            "✅ 请输入要解封的用户ID：\n\n示例：<code>123456789</code>",
            parse_mode='HTML'
        )
        self.bot.register_next_step_handler(msg, self.handle_unban_user)
    
    # 处理解封用户
    def handle_unban_user(self, message):
        try:
            user_id = int(message.text.strip())
            
            if unban_user(user_id):
                self.bot.reply_to(message, f"✅ 用户 {user_id} 已解封")
            else:
                self.bot.reply_to(message, f"❌ 解封用户 {user_id} 失败或用户未被封禁")
                
        except ValueError:
            self.bot.reply_to(message, "❌ 用户ID必须是数字")
        except Exception as e:
            self.bot.reply_to(message, f"❌ 解封用户失败: {e}")
    
    # 显示封禁用户列表
    def show_banned_users(self, message):
        banned_users = load_banned_users()
        total_banned = len(banned_users)
        
        if total_banned == 0:
            self.bot.send_message(message.chat.id, "📋 当前没有封禁用户")
            return
        
        banned_list_text = f"""
<b>🚫 封禁用户列表</b>

总封禁用户: {total_banned}

"""
        
        for i, (user_id, ban_info) in enumerate(list(banned_users.items())[:20], 1):
            banned_time = datetime.datetime.fromisoformat(ban_info.get('banned_time', '2000-01-01'))
            reason = ban_info.get('reason', '未知原因')
            banned_by = ban_info.get('banned_by', '未知管理员')
            
            banned_list_text += f"{i}. 用户 {user_id}\n"
            banned_list_text += f"   原因: {reason}\n"
            banned_list_text += f"   封禁时间: {banned_time.strftime('%Y-%m-%d %H:%M')}\n"
            banned_list_text += f"   操作员: {banned_by}\n\n"
        
        if total_banned > 20:
            banned_list_text += f"... 还有 {total_banned - 20} 个封禁用户未显示"
        
        self.bot.send_message(message.chat.id, banned_list_text, parse_mode='HTML')

    # 请求广播消息
    def request_broadcast_message(self, message):
        broadcast_menu = """
    <b>📢 广播消息类型选择</b>

    请选择要发送的广播消息类型：

    1. 📝 <b>纯文本消息</b> - 基本文本内容
    2. 🎨 <b>HTML格式消息</b> - 支持HTML格式和样式
    3. 🖼️ <b>图片+文字</b> - 发送图片和文字说明
    4. 📎 <b>文件+文字</b> - 发送文件和文字说明
    5. 🔘 <b>带按钮消息</b> - 文本消息+内联按钮
    6. 🖼️🔘 <b>图片+按钮</b> - 图片+文字+按钮

    回复对应数字选择消息类型：
    """
        
        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("1️⃣ 纯文本", callback_data="broadcast_type_text"),
            InlineKeyboardButton("2️⃣ HTML格式", callback_data="broadcast_type_html")
        )
        markup.row(
            InlineKeyboardButton("3️⃣ 图片+文字", callback_data="broadcast_type_photo"),
            InlineKeyboardButton("4️⃣ 文件+文字", callback_data="broadcast_type_document")
        )
        markup.row(
            InlineKeyboardButton("5️⃣ 带按钮", callback_data="broadcast_type_buttons"),
            InlineKeyboardButton("6️⃣ 图片+按钮", callback_data="broadcast_type_photo_buttons")
        )
        # 取消广播按钮
        markup.row(InlineKeyboardButton("❌ 取消发送", callback_data="broadcast_cancel"))
        self.bot.send_message(
            message.chat.id,
            broadcast_menu,
            parse_mode='HTML',
            reply_markup=markup
        )

    # 处理按钮配置
    def request_button_config(self, message, session):
        """请求配置按钮"""
        button_guide = """
    <b>🔘 按钮配置指南</b>

    请按以下格式发送按钮配置：

    <code>按钮文字1 - 链接1
    按钮文字2 - 链接2
    ...</code>

    <u>示例：</u>
    <code>加入频道 - https://t.me/yourchannel
    联系客服 - https://t.me/yourbot
    查看网站 - https://www.example.com</code>

    💡 每行一个按钮，格式：<code>按钮文字 - 链接</code>
    💡 最多支持3行按钮，每行最多3个按钮
    💡 回复 '跳过' 则不添加按钮
    """
        
        # 创建键盘
        markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markup.row("跳过", "取消")
        
        session['step'] = 'waiting_buttons'
        self.bot.send_message(
            message.chat.id,
            button_guide,
            parse_mode='HTML',
            reply_markup=markup
        )

    # 解析按钮配置
    def parse_buttons_config(self, button_text):
        """解析按钮配置文本"""
        if not button_text or button_text.lower() == '跳过':
            return None
        
        buttons = []
        lines = button_text.strip().split('\n')
        
        for line in lines:
            if '-' in line:
                parts = line.split('-', 1)
                if len(parts) == 2:
                    text = parts[0].strip()
                    url = parts[1].strip()
                    
                    # 验证URL格式
                    if url.startswith(('http://', 'https://', 'tg://', 't.me/')):
                        buttons.append((text, url))
        
        return buttons if buttons else None

    # 创建按钮键盘
    def create_broadcast_buttons(self, buttons_config):
        """根据配置创建内联键盘"""
        if not buttons_config:
            return None
        
        markup = InlineKeyboardMarkup()
        
        # 每行最多3个按钮
        row_buttons = []
        for text, url in buttons_config:
            row_buttons.append(InlineKeyboardButton(text, url=url))
            
            # 每3个按钮换一行
            if len(row_buttons) >= 3:
                markup.row(*row_buttons)
                row_buttons = []
        
        # 添加剩余按钮
        if row_buttons:
            markup.row(*row_buttons)
        
        return markup
        # 显示数据导出选项
    def show_data_export_options(self, message):
        try:
            # 直接开始导出，不显示菜单
            self.bot.send_message(
                message.chat.id,
                "📤 <b>正在打包数据文件...</b>",
                parse_mode='HTML'
            )
            
            # 直接打包并发送数据
            self.export_all_data(message)
            
        except Exception as e:
            log_message(f"数据导出失败: {e}", "ERROR")
            self.bot.reply_to(message, f"❌ 数据导出失败: {e}")

    # 导出所有数据为ZIP文件
    def export_all_data(self, message):
        try:
            # 生成带时间戳的文件名
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            zip_filename = f"UUSearchBot_backup_{timestamp}.zip"
            
            # 创建临时ZIP文件
            with tempfile.NamedTemporaryFile(delete=False, suffix='.zip') as tmp_file:
                zip_path = tmp_file.name
            
            # 创建ZIP文件
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                file_count = 0
                
                # 打包数据目录
                if os.path.exists(DATA_DIR):
                    for root, dirs, files in os.walk(DATA_DIR):
                        for file in files:
                            file_path = os.path.join(root, file)
                            # 在ZIP中的相对路径
                            arcname = os.path.join("data", os.path.relpath(file_path, DATA_DIR))
                            zipf.write(file_path, arcname)
                            file_count += 1
                            log_message(f"已添加数据文件: {file_path}", "EXPORT")
                
                # 打包日志目录
                if os.path.exists(LOG_DIR):
                    for root, dirs, files in os.walk(LOG_DIR):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arcname = os.path.join("log", os.path.relpath(file_path, LOG_DIR))
                            zipf.write(file_path, arcname)
                            file_count += 1
                            log_message(f"已添加日志文件: {file_path}", "EXPORT")
                
                # 打包临时目录
                if os.path.exists(TEMP_DIR):
                    for root, dirs, files in os.walk(TEMP_DIR):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arcname = os.path.join("temp", os.path.relpath(file_path, TEMP_DIR))
                            zipf.write(file_path, arcname)
                            file_count += 1
                            log_message(f"已添加临时文件: {file_path}", "EXPORT")
            
            # 获取文件大小
            zip_size = os.path.getsize(zip_path)
            
            # 发送ZIP文件，指定文件名
            with open(zip_path, 'rb') as f:
                self.bot.send_document(
                    message.chat.id,
                    f,
                    visible_file_name=zip_filename,  # 指定显示的文件名
                    caption=f"📦 <b>完整数据备份</b>\n\n📁 文件名称: {zip_filename}\n📊 文件数量: {file_count} 个\n💾 压缩大小: {self.format_file_size(zip_size)}\n⏰ 导出时间: {get_current_time()}",
                    parse_mode='HTML'
                )
            
            # 清理临时文件
            os.unlink(zip_path)
            
            log_message(f"数据导出成功: {file_count} 个文件, 文件名: {zip_filename}", "EXPORT")
            
        except Exception as e:
            log_message(f"导出数据失败: {e}", "ERROR")
            self.bot.reply_to(message, f"❌ 导出数据失败: {e}")

    # 格式化文件大小
    def format_file_size(self, size_bytes):
        if size_bytes == 0:
            return "0 B"
        size_names = ["B", "KB", "MB", "GB"]
        i = 0
        while size_bytes >= 1024 and i < len(size_names) - 1:
            size_bytes /= 1024.0
            i += 1
        return f"{size_bytes:.2f} {size_names[i]}"

    # 处理广播消息处理器
    def handle_broadcast_message(self, message):
        try:
            user_id = message.from_user.id
            
            # 检查是否有广播会话
            if not hasattr(self, 'broadcast_sessions') or user_id not in self.broadcast_sessions:
                self.request_broadcast_message(message)
                return
            
            session = self.broadcast_sessions[user_id]
            broadcast_type = session['type']
            current_step = session.get('step', 'waiting_content')
            
            log_message(f"广播处理: 类型={broadcast_type}, 步骤={current_step}, 内容类型={message.content_type}", "LOG")
            
            # 检查取消命令
            if message.content_type == 'text' and message.text.strip().lower() in ['取消', 'cancel', '❌取消']:
                self.handle_broadcast_cancel_message(message)
                return
            
            if current_step == 'waiting_content':
                if broadcast_type in ['photo', 'photo_buttons']:
                    # 处理图片类型
                    if message.photo:
                        file_id = message.photo[-1].file_id
                        session['media_file_id'] = file_id
                        
                        # 创建带取消按钮的键盘
                        markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
                        markup.row("跳过", "取消")
                        
                        if broadcast_type == 'photo_buttons':
                            session['step'] = 'waiting_caption'
                            self.bot.reply_to(
                                message, 
                                "✅ 图片已接收，请发送文字说明：\n回复 '跳过' 则不添加文字\n回复 '取消' 则取消广播",
                                reply_markup=markup
                            )
                        else:
                            session['step'] = 'waiting_caption'
                            self.bot.reply_to(
                                message, 
                                "✅ 图片已接收，请发送文字说明（如需添加）：\n回复 '跳过' 则不添加文字说明\n回复 '取消' 则取消广播",
                                reply_markup=markup
                            )
                    else:
                        self.bot.reply_to(message, "❌ 请发送图片，而不是文字")
                        
                elif broadcast_type in ['document']:
                    # 处理文件类型
                    if message.document:
                        file_id = message.document.file_id
                        session['media_file_id'] = file_id
                        session['step'] = 'waiting_caption'
                        
                        # 创建带取消按钮的键盘
                        markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
                        markup.row("跳过", "取消")
                        
                        self.bot.reply_to(
                            message, 
                            "✅ 文件已接收，请发送文字说明（如需添加）：\n回复 '跳过' 则不添加文字说明\n回复 '取消' 则取消广播",
                            reply_markup=markup
                        )
                    else:
                        self.bot.reply_to(message, "❌ 请发送文件，而不是文字")
                        
                elif broadcast_type in ['text', 'html', 'buttons']:
                    # 处理文本类型
                    if message.content_type != 'text':
                        self.bot.reply_to(message, "❌ 请发送文本内容")
                        return
                    
                    session['content'] = message.text
                    
                    if broadcast_type == 'buttons':
                        # 对于按钮类型，接下来配置按钮
                        self.request_button_config(message, session)
                    else:
                        # 对于纯文本和HTML，直接开始广播
                        self.start_broadcast(message, session)
                        
            elif current_step == 'waiting_caption':
                # 处理文字说明
                if message.content_type != 'text':
                    self.bot.reply_to(message, "❌ 请发送文字说明")
                    return
                    
                caption = message.text if message.text.lower() != '跳过' else ""
                session['caption'] = caption
                
                if broadcast_type == 'photo_buttons':
                    # 图片+按钮类型，接下来配置按钮
                    self.request_button_config(message, session)
                else:
                    # 普通图片/文件类型，开始广播
                    self.start_broadcast(message, session)
                    
            elif current_step == 'waiting_buttons':
                # 处理按钮配置
                if message.content_type != 'text':
                    self.bot.reply_to(message, "❌ 请发送按钮配置")
                    return
                    
                buttons_config = self.parse_buttons_config(message.text)
                session['buttons_config'] = buttons_config
                self.start_broadcast(message, session)
                
        except Exception as e:
            log_message(f"处理广播消息失败: {e}", "ERROR")
            self.bot.reply_to(message, f"❌ 处理广播消息失败: {e}")

    # 处理消息中的取消命令
    def handle_broadcast_cancel_message(self, message):
        try:
            user_id = message.from_user.id
            # 清理广播会话
            if hasattr(self, 'broadcast_sessions') and user_id in self.broadcast_sessions:
                del self.broadcast_sessions[user_id]
            
            # 移除自定义键盘
            self.bot.send_message(
                message.chat.id,
                "❌ 广播已取消",
                reply_markup=self.remove_keyboard()
            )
            
        except Exception as e:
            log_message(f"取消广播失败: {e}", "ERROR")
            self.bot.reply_to(message, "❌ 取消广播失败")

    # 执行广播发送
    def start_broadcast(self, message, session):
        try:
            if not session.get('confirmed'):
                self.show_broadcast_preview(message, session)
                return
            
            # 获取所有用户
            all_users = self.get_all_possible_users()
            total_users = len(all_users)
            
            if total_users == 0:
                self.bot.reply_to(message, "❌ 未找到任何用户")
                return
            
            # 准备按钮键盘
            buttons_markup = None
            if session.get('buttons_config'):
                buttons_markup = self.create_broadcast_buttons(session['buttons_config'])
            
            # 发送广播开始消息
            progress_msg = self.bot.send_message(
                message.chat.id,
                f"📢 开始广播消息...\n目标用户数: {total_users}\n消息类型: {session['type']}\n\n发送中...",
                parse_mode='HTML'
            )
            
            success_count = 0
            fail_count = 0
            processed = 0
            
            broadcast_type = session['type']
            
            for user_id in all_users:
                try:
                    # 跳过被封禁的用户
                    if is_user_banned(user_id):
                        fail_count += 1
                        processed += 1
                        continue
                    
                    # 根据消息类型发送不同的内容
                    if broadcast_type == 'text':
                        self.bot.send_message(
                            user_id,
                            f"📢 <b>系统广播</b>\n\n{session['content']}",
                            parse_mode='HTML'
                        )
                        
                    elif broadcast_type == 'html':
                        self.bot.send_message(
                            user_id,
                            f"📢 <b>系统广播</b>\n\n{session['content']}",
                            parse_mode='HTML',
                            reply_markup=buttons_markup
                        )
                        
                    elif broadcast_type == 'buttons':
                        self.bot.send_message(
                            user_id,
                            f"📢 <b>系统广播</b>\n\n{session['content']}",
                            parse_mode='HTML',
                            reply_markup=buttons_markup
                        )
                        
                    elif broadcast_type == 'photo':
                        self.bot.send_photo(
                            user_id,
                            photo=session['media_file_id'],
                            caption=f"📢 <b>系统广播</b>\n\n{session.get('caption', '')}",
                            parse_mode='HTML'
                        )
                        
                    elif broadcast_type == 'photo_buttons':
                        self.bot.send_photo(
                            user_id,
                            photo=session['media_file_id'],
                            caption=f"📢 <b>系统广播</b>\n\n{session.get('caption', '')}",
                            parse_mode='HTML',
                            reply_markup=buttons_markup
                        )
                        
                    elif broadcast_type == 'document':
                        self.bot.send_document(
                            user_id,
                            document=session['media_file_id'],
                            caption=f"📢 <b>系统广播</b>\n\n{session.get('caption', '')}",
                            parse_mode='HTML'
                        )
                    
                    success_count += 1
                    
                    # 每发送10个用户更新一次进度
                    processed += 1
                    if processed % 10 == 0:
                        try:
                            self.bot.edit_message_text(
                                f"📢 广播消息发送中...\n目标用户数: {total_users}\n已处理: {processed}/{total_users}\n成功: {success_count} | 失败: {fail_count}",
                                message.chat.id,
                                progress_msg.message_id,
                                parse_mode='HTML'
                            )
                        except:
                            pass
                    
                    # 短暂延迟避免频繁发送
                    time.sleep(0.1)
                    
                except Exception as e:
                    fail_count += 1
                    processed += 1
                    log_message(f"向用户 {user_id} 发送广播失败: {e}", "ERROR")
            
            # 清理会话
            if hasattr(self, 'broadcast_sessions') and message.from_user.id in self.broadcast_sessions:
                del self.broadcast_sessions[message.from_user.id]
            
            # 发送广播完成消息
            result_text = f"""
    📢 <b>广播完成</b>

    ✅ 成功发送: {success_count} 个用户
    ❌ 发送失败: {fail_count} 个用户
    📊 成功率: {success_count/total_users*100:.1f}%
    🎯 消息类型: {broadcast_type}

    💡 失败原因可能是用户已封禁、已阻止机器人或用户ID无效
    """
            self.bot.edit_message_text(
                result_text,
                message.chat.id,
                progress_msg.message_id,
                parse_mode='HTML'
            )
            
            log_message(f"管理员 {message.from_user.id} 发送{broadcast_type}类型广播，成功: {success_count}, 失败: {fail_count}", "BROADCAST")
            
        except Exception as e:
            log_message(f"执行广播失败: {e}", "ERROR")
            self.bot.reply_to(message, f"❌ 广播执行失败: {e}")

    # 获取所有可能的用户（合并多个数据源）
    def get_all_possible_users(self):
        all_users = set()
        
        # 1. 从用户使用统计中获取
        user_stats = load_user_usage_stats()
        for user_id_str in user_stats.keys():
            all_users.add(int(user_id_str))
        
        # 2. 从VIP用户中获取
        vip_users = load_vip_users()
        for user_id_str in vip_users.keys():
            all_users.add(int(user_id_str))
        
        # 3. 从封禁用户中获取
        if True:       # 改为 False 可以关闭对封禁用户的广播
            banned_users = load_banned_users()
            for user_id_str in banned_users.keys():
                all_users.add(int(user_id_str))
        
        # 4. 从搜索次数记录中获取
        search_counts = load_user_search_counts()
        for user_id_str in search_counts.keys():
            all_users.add(int(user_id_str))
        
        # 5. 从随机次数记录中获取  
        random_counts = load_user_random_counts()
        for user_id_str in random_counts.keys():
            all_users.add(int(user_id_str))
        
        return list(all_users)
    
    # 热搜管理相关功能
    def show_hot_search_list(self, message):
        top_searches = get_top_hot_searches(20)  # 显示前20名
        
        if not top_searches:
            self.bot.send_message(message.chat.id, "📋 当前热搜榜单为空")
            return
        
        hot_searches_text = "🔥 <b>热搜榜单 TOP 20</b>\n\n"
        
        for i, (keyword, count) in enumerate(top_searches, 1):
            hot_searches_text += f"{i}. <code>{keyword}</code> - {count}次\n"
        
        self.bot.send_message(message.chat.id, hot_searches_text, parse_mode='HTML')

    def request_edit_hot_search(self, message):
        msg = self.bot.send_message(
            message.chat.id,
            "✏️ 请输入要添加或修改的热搜关键词和次数（用空格分隔）：\n\n"
            "示例：<code>电影 100</code>\n"
            "⚠️ 注意：禁止包含 @ 信息和链接广告\n"
            "如需删除关键词，请将次数设为0",
            parse_mode='HTML'
        )
        self.bot.register_next_step_handler(msg, self.handle_edit_hot_search)

    def handle_edit_hot_search(self, message):
        try:
            parts = message.text.split(' ', 1)
            if len(parts) < 2:
                self.bot.reply_to(message, "❌ 格式错误，请提供关键词和次数")
                return
            
            keyword = parts[0].strip()
            count = int(parts[1])
            
            # 检查是否包含禁止内容
            if contains_advertisement(keyword):
                self.bot.reply_to(message, "❌ 热搜关键词不能包含 @ 信息、链接或广告内容")
                return
            
            hot_searches_data = load_hot_searches()
            if not hot_searches_data:
                self.bot.reply_to(message, "❌ 加载热搜数据失败")
                return
            
            if "search_counts" not in hot_searches_data:
                hot_searches_data["search_counts"] = {}
            
            if count <= 0:
                # 删除关键词
                if keyword in hot_searches_data["search_counts"]:
                    del hot_searches_data["search_counts"][keyword]
                    action = "删除"
                else:
                    self.bot.reply_to(message, f"❌ 关键词 '{keyword}' 不存在")
                    return
            else:
                # 添加或修改关键词
                hot_searches_data["search_counts"][keyword] = count
                action = "添加" if keyword not in hot_searches_data["search_counts"] else "修改"
            
            hot_searches_data["last_updated"] = datetime.datetime.now().isoformat()
            
            if save_hot_searches(hot_searches_data):
                self.bot.reply_to(message, f"✅ 已{action}热搜关键词：{keyword} - {count}次")
            else:
                self.bot.reply_to(message, "❌ 保存热搜数据失败")
                
        except ValueError:
            self.bot.reply_to(message, "❌ 次数必须是数字")
        except Exception as e:
            self.bot.reply_to(message, f"❌ 修改热搜失败: {e}")

    def clear_hot_searches(self, message):
        try:
            hot_searches_data = {
                "last_updated": datetime.datetime.now().isoformat(),
                "search_counts": {}
            }
            
            if save_hot_searches(hot_searches_data):
                self.bot.reply_to(message, "✅ 已清空热搜榜单")
            else:
                self.bot.reply_to(message, "❌ 清空热搜榜单失败")
        except Exception as e:
            self.bot.reply_to(message, f"❌ 清空热搜榜单失败: {e}")

    def reset_hot_search_counts(self, message):
        try:
            hot_searches_data = load_hot_searches()
            if not hot_searches_data:
                self.bot.reply_to(message, "❌ 加载热搜数据失败")
                return
            
            # 将所有关键词的计数设为1
            for keyword in hot_searches_data.get("search_counts", {}):
                hot_searches_data["search_counts"][keyword] = 1
            
            hot_searches_data["last_updated"] = datetime.datetime.now().isoformat()
            
            if save_hot_searches(hot_searches_data):
                self.bot.reply_to(message, "✅ 已重置所有热搜关键词计数为1")
            else:
                self.bot.reply_to(message, "❌ 重置热搜计数失败")
        except Exception as e:
            self.bot.reply_to(message, f"❌ 重置热搜计数失败: {e}")

    # 用户私信功能
    def request_private_message(self, message):
        msg = self.bot.send_message(
            message.chat.id,
            "💬 请输入要发送私信的用户ID和消息内容（用空格分隔）：\n\n"
            "示例：<code>123456789 您好，这是管理员发送的私信</code>",
            parse_mode='HTML'
        )
        self.bot.register_next_step_handler(msg, self.handle_private_message)

    def handle_private_message(self, message):
        try:
            parts = message.text.split(' ', 1)
            if len(parts) < 2:
                self.bot.reply_to(message, "❌ 格式错误，请提供用户ID和消息内容")
                return
            
            user_id = int(parts[0])
            pm_content = parts[1]
            
            try:
                self.bot.send_message(
                    user_id,
                    f"💌 <b>管理员私信</b>\n\n{pm_content}",
                    parse_mode='HTML'
                )
                self.bot.reply_to(message, f"✅ 私信已发送给用户 {user_id}")
                log_message(f"管理员 {message.from_user.id} 向用户 {user_id} 发送私信", "PM")
            except Exception as e:
                self.bot.reply_to(message, f"❌ 发送私信失败: 用户可能已阻止机器人或不存在")
                
        except ValueError:
            self.bot.reply_to(message, "❌ 用户ID必须是数字")
        except Exception as e:
            self.bot.reply_to(message, f"❌ 发送私信失败: {e}")

    def show_pm_user_list(self, message):
        user_stats = load_user_usage_stats()
        total_users = len(user_stats)
        
        # 按最后活跃时间排序
        sorted_users = sorted(
            user_stats.items(),
            key=lambda x: datetime.datetime.fromisoformat(x[1].get('last_active', '2000-01-01')),
            reverse=True
        )[:15]  # 只显示前15个用户
        
        user_list_text = f"""
<b>👤 可私信用户列表 (最近活跃的前15个)</b>

总用户数: {total_users}

"""
        
        for i, (user_id, stats) in enumerate(sorted_users, 1):
            last_active = datetime.datetime.fromisoformat(stats.get('last_active', '2000-01-01'))
            days_ago = (datetime.datetime.now() - last_active).days
            
            user_list_text += f"{i}. 用户 <code>{user_id}</code>\n"
            user_list_text += f"   最后活跃: {days_ago}天前 | 搜索: {stats.get('total_searches', 0)}次\n"
        
        user_list_text += f"\n💡 复制用户ID用于私信功能"
        
        self.bot.send_message(message.chat.id, user_list_text, parse_mode='HTML')

    # 列出所有日志文件
    def list_log_files(self, message):
        try:
            if not os.path.exists(LOG_DIR):
                self.bot.send_message(message.chat.id, "❌ 日志目录不存在")
                return
            
            log_files = [f for f in os.listdir(LOG_DIR) if f.endswith('.log')]
            log_files.sort(reverse=True)  # 按时间倒序排列
            
            if not log_files:
                self.bot.send_message(message.chat.id, "📁 暂无日志文件")
                return
            
            # 构建日志文件列表
            log_list = "<b>📋 日志文件列表</b>\n\n"
            for i, log_file in enumerate(log_files[:20], 1):  # 最多显示20个
                file_path = os.path.join(LOG_DIR, log_file)
                file_size = os.path.getsize(file_path)
                log_list += f"{i}. <code>{log_file}</code> ({file_size} bytes)\n"
            
            if len(log_files) > 20:
                log_list += f"\n... 还有 {len(log_files) - 20} 个文件未显示"
            
            log_list += "\n\n发送 <code>/log 文件名</code> 获取具体日志文件\n示例: <code>/log LOG_20241201_120000.log</code>"
            
            self.bot.send_message(message.chat.id, log_list, parse_mode='HTML')
            
        except Exception as e:
            log_message(f"列出日志文件失败: {e}", "ERROR")
            self.bot.send_message(message.chat.id, f"❌ 列出日志文件失败: {e}")
    
    # 发送当前日志文件
    def send_current_log(self, message):
        try:
            if LOG_FILEPATH and os.path.exists(LOG_FILEPATH):
                with open(LOG_FILEPATH, 'rb') as f:
                    self.bot.send_document(
                        message.chat.id,
                        f,
                        caption=f"📄 当前日志文件: {os.path.basename(LOG_FILEPATH)}"
                    )
            else:
                self.bot.send_message(message.chat.id, "❌ 当前日志文件不存在")
        except Exception as e:
            log_message(f"发送当前日志失败: {e}", "ERROR")
            self.bot.send_message(message.chat.id, f"❌ 发送日志文件失败: {e}")
    
    # 发送指定日志文件
    def send_specific_log(self, message, log_filename):
        try:
            log_path = os.path.join(LOG_DIR, log_filename)
            
            if not os.path.exists(log_path):
                self.bot.send_message(message.chat.id, f"❌ 日志文件不存在: {log_filename}")
                return
            
            # 检查文件大小，如果太大则分割发送
            file_size = os.path.getsize(log_path)
            max_size = 50 * 1024 * 1024  # 50MB Telegram限制
            
            if file_size > max_size:
                self.bot.send_message(message.chat.id, f"📁 文件过大 ({file_size} bytes)，正在分割发送...")
                self.send_large_log_file(message, log_path)
            else:
                with open(log_path, 'rb') as f:
                    self.bot.send_document(
                        message.chat.id,
                        f,
                        caption=f"📄 日志文件: {log_filename}"
                    )
                
        except Exception as e:
            log_message(f"发送指定日志失败: {e}", "ERROR")
            self.bot.send_message(message.chat.id, f"❌ 发送日志文件失败: {e}")
    
    # 发送大日志文件（分割发送）
    def send_large_log_file(self, message, log_path):
        try:
            ensure_temp_dir()
            chunk_size = 45 * 1024 * 1024
            part_num = 1
            
            with open(log_path, 'r', encoding='utf-8') as f:
                while True:
                    chunk = f.read(10 * 1024 * 1024)
                    if not chunk:
                        break
                    
                    temp_filename = f"{os.path.basename(log_path)}.part{part_num}"
                    temp_filepath = os.path.join(TEMP_DIR, temp_filename)
                    
                    with open(temp_filepath, 'w', encoding='utf-8') as temp_file:
                        temp_file.write(chunk)
                    
                    with open(temp_filepath, 'rb') as temp_file:
                        self.bot.send_document(
                            message.chat.id,
                            temp_file,
                            caption=f"📄 {os.path.basename(log_path)} 第{part_num}部分"
                        )
                    
                    os.remove(temp_filepath)
                    part_num += 1
                    
                    time.sleep(1)
            
            self.bot.send_message(message.chat.id, f"✅ 日志文件已分割为 {part_num-1} 部分发送完成")
            
        except Exception as e:
            log_message(f"发送大日志文件失败: {e}", "ERROR")
            self.bot.send_message(message.chat.id, f"❌ 发送大日志文件失败: {e}")
    
    # 重置用户限制
    def reset_user_limits(self, message):
        self.user_search_counts = {}
        save_user_search_counts(self.user_search_counts)
        self.user_random_counts = {}
        save_user_random_counts(self.user_random_counts)
        
        # 重置请求频率限制
        global USER_REQUEST_LIMITS, USER_SEARCH_PATTERNS
        USER_REQUEST_LIMITS = {}
        USER_SEARCH_PATTERNS = {}
        
        self.bot.reply_to(message, "✅ 已重置所有用户搜索、随机次数和请求频率限制")
    
    # 处理管理员文本命令
    def handle_admin_text_commands(self, message):
        if message.from_user.id not in self.ADMIN_IDS:
            return
        
        text = message.text.strip()
        
        if text.startswith("/vip "):
            self.handle_add_vip_command(message)
        elif text.startswith("/unvip "):
            self.handle_remove_vip_command(message)
        elif text.startswith("/user "):
            self.handle_user_info_command(message)
        elif text.startswith("/log "):
            self.handle_log_command(message)
    
    # 处理添加VIP命令
    def handle_add_vip_command(self, message):
        try:
            parts = message.text.split()
            if len(parts) >= 3:
                user_id = int(parts[1])
                days = int(parts[2])
                self.add_vip_user(user_id, days)
                self.bot.reply_to(message, f"✅ 已为用户 {user_id} 添加 {days} 天VIP")
            else:
                self.bot.reply_to(message, "❌ 格式错误，使用: /vip 用户ID 天数")
        except Exception as e:
            self.bot.reply_to(message, f"❌ 添加VIP失败: {e}")
    
    # 处理移除VIP命令
    def handle_remove_vip_command(self, message):
        try:
            user_id = int(message.text.split()[1])
            user_id_str = str(user_id)
            if user_id_str in self.vip_users:
                del self.vip_users[user_id_str]
                save_vip_users(self.vip_users)
                self.bot.reply_to(message, f"✅ 已移除用户 {user_id} 的VIP权限")
            else:
                self.bot.reply_to(message, f"❌ 用户 {user_id} 不是VIP")
        except Exception as e:
            self.bot.reply_to(message, f"❌ 移除VIP失败: {e}")
    
    # 处理用户信息命令
    def handle_user_info_command(self, message):
        try:
            user_id = int(message.text.split()[1])
            user_id_str = str(user_id)
            user_stats = load_user_usage_stats()
            
            if user_id_str not in user_stats:
                self.bot.reply_to(message, f"❌ 用户 {user_id} 不存在或未使用过机器人")
                return
            
            stats = user_stats[user_id_str]
            is_vip = self.is_vip_user(user_id)
            is_banned = is_user_banned(user_id)
            search_count = stats.get('total_searches', 0)
            first_seen = datetime.datetime.fromisoformat(stats.get('first_seen', '2000-01-01'))
            last_active = datetime.datetime.fromisoformat(stats.get('last_active', '2000-01-01'))
            
            user_info = f"""
<b>👤 用户详细信息</b>

🆔 ID: <code>{user_id}</code>
⭐ VIP状态: {'✅ 是' if is_vip else '❌ 否'}
🚫 封禁状态: {'✅ 是' if is_banned else '❌ 否'}
🔍 总搜索次数: {search_count} 次
📅 首次使用: {first_seen.strftime('%Y-%m-%d %H:%M')}
🕒 最后活跃: {last_active.strftime('%Y-%m-%d %H:%M')}
"""
            
            # 添加最近搜索关键词（最多5个）
            recent_keywords = stats.get('search_keywords', [])[-5:]
            if recent_keywords:
                user_info += "\n<b>最近搜索关键词:</b>\n"
                for keyword_data in reversed(recent_keywords):
                    keyword = keyword_data.get('keyword', '未知')
                    time_str = datetime.datetime.fromisoformat(keyword_data.get('time', '2000-01-01')).strftime('%m-%d %H:%M')
                    user_info += f"• {keyword} ({time_str})\n"
            
            self.bot.reply_to(message, user_info, parse_mode='HTML')
        except Exception as e:
            self.bot.reply_to(message, f"❌ 获取用户信息失败: {e}")
    
    # 处理日志命令
    def handle_log_command(self, message):
        try:
            parts = message.text.split()
            if len(parts) >= 2:
                log_filename = parts[1]
                self.send_specific_log(message, log_filename)
            else:
                self.bot.reply_to(message, "❌ 格式错误，使用: /log 文件名")
        except Exception as e:
            self.bot.reply_to(message, f"❌ 获取日志文件失败: {e}")
    
    # 显示帮助信息
    def show_help(self, message):
        # 检查用户是否被封禁
        if is_user_banned(message.from_user.id):
            self.bot.send_message(message.chat.id, "❌ 无权限")
            return
        
        self.bot.send_message(
            message.chat.id,
            self.HelpMessage,
            parse_mode='HTML',
            reply_markup=self.create_main_keyboard()
        )
    
    # 显示用户信息
    def show_user_info(self, message):
        # 检查用户是否被封禁
        if is_user_banned(message.from_user.id):
            self.bot.send_message(message.chat.id, "❌ 无权限")
            return
        
        user = message.from_user
        is_vip = self.is_vip_user(user.id)
        vip_status = "✅ VIP会员" if is_vip else "❌ 非VIP会员"
        remaining_time = self.get_vip_remaining_time(user.id) if is_vip else "无"
        search_count = self.user_search_counts.get(str(user.id), 0)
        remaining_searches = 10 - search_count if not is_vip else "无限制"
        
        user_info = f"""
<b>👤 用户信息</b>

🆔 ID: <code>{user.id}</code>
👤 姓名: {user.first_name or '未设置'}
📛 用户名: @{user.username or '未设置'}
⭐ VIP状态: {vip_status}
⏰ VIP剩余: {remaining_time}
🔍 今日搜索: {search_count} 次
📄 剩余搜索: {remaining_searches} 次
"""
        self.bot.send_message(
            message.chat.id,
            user_info,
            parse_mode='HTML',
            reply_markup=self.create_main_keyboard()
        )

    # 处理广播确认发送
    def handle_broadcast_confirm(self, call):
        try:
            user_id = call.from_user.id
            if hasattr(self, 'broadcast_sessions') and user_id in self.broadcast_sessions:
                session = self.broadcast_sessions[user_id]
                # 设置确认标志
                session['confirmed'] = True
                
                # 删除预览消息
                try:
                    self.bot.delete_message(call.message.chat.id, call.message.message_id)
                except:
                    pass
                
                # 创建临时消息对象用于start_broadcast
                temp_message = type('obj', (object,), {
                    'from_user': call.from_user,
                    'chat': call.message.chat
                })()
                
                # 开始广播
                self.start_broadcast(temp_message, session)
                
            self.bot.answer_callback_query(call.id, "开始发送广播...")
            
        except Exception as e:
            log_message(f"确认广播失败: {e}", "ERROR")
            self.bot.answer_callback_query(call.id, "确认失败")

    # 处理广播取消发送
    def handle_broadcast_cancel(self, call):
        try:
            user_id = call.from_user.id
            # 清理广播会话
            if hasattr(self, 'broadcast_sessions') and user_id in self.broadcast_sessions:
                del self.broadcast_sessions[user_id]
            
            # 删除原消息
            try:
                self.bot.delete_message(call.message.chat.id, call.message.message_id)
            except:
                pass
            
            # 发送取消通知并返回管理员菜单
            self.bot.send_message(
                call.message.chat.id,
                "❌ 广播已取消",
                reply_markup=self.create_admin_keyboard()
            )
            
            self.bot.answer_callback_query(call.id, "广播已取消")
            
        except Exception as e:
            log_message(f"取消广播失败: {e}", "ERROR")
            self.bot.answer_callback_query(call.id, "取消失败")

    # 处理广播重新编辑
    def handle_broadcast_edit(self, call):
        try:
            user_id = call.from_user.id
            if hasattr(self, 'broadcast_sessions') and user_id in self.broadcast_sessions:
                session = self.broadcast_sessions[user_id]
                
                # 删除预览消息
                try:
                    self.bot.delete_message(call.message.chat.id, call.message.message_id)
                except:
                    pass
                
                # 根据广播类型重新开始编辑流程
                broadcast_type = session['type']
                if broadcast_type in ['text', 'html', 'buttons']:
                    # 重新请求文本内容
                    self.bot.send_message(
                        call.message.chat.id,
                        "✏️ 请重新发送广播文本内容：",
                        parse_mode='HTML'
                    )
                elif broadcast_type in ['photo', 'photo_buttons']:
                    # 重新请求图片
                    self.bot.send_message(
                        call.message.chat.id,
                        "🖼️ 请重新发送图片：",
                        parse_mode='HTML'
                    )
                elif broadcast_type == 'document':
                    # 重新请求文件
                    self.bot.send_message(
                        call.message.chat.id,
                        "📎 请重新发送文件：",
                        parse_mode='HTML'
                    )
                
                # 重置会话步骤
                session['step'] = 'waiting_content'
                session['confirmed'] = False
                
            self.bot.answer_callback_query(call.id, "请重新编辑广播内容")
            
        except Exception as e:
            log_message(f"重新编辑广播失败: {e}", "ERROR")
            self.bot.answer_callback_query(call.id, "重新编辑失败")

    # 显示广播预览和确认按钮
    def show_broadcast_preview(self, message, session):
        try:
            broadcast_type = session['type']
            preview_text = self.generate_broadcast_preview(session)
            
            # 创建确认键盘
            markup = InlineKeyboardMarkup()
            markup.row(
                InlineKeyboardButton("✅ 确认发送", callback_data="broadcast_confirm"),
                InlineKeyboardButton("❌ 取消发送", callback_data="broadcast_cancel")
            )
            markup.row(
                InlineKeyboardButton("✏️ 重新编辑", callback_data="broadcast_edit")
            )
            
            # 获取用户数量
            try:
                all_users = self.get_all_possible_users()
                total_users = len(all_users)
            except Exception as e:
                log_message(f"获取用户数量失败: {e}", "ERROR")
                total_users = 0
            
            # 发送预览消息
            preview_message = f"""
📋 广播预览

{preview_text}

发送统计：
• 目标用户数: {total_users}
• 消息类型: {broadcast_type}

请确认是否发送此广播：
"""
            
            # 根据消息类型发送不同的预览
            if broadcast_type in ['photo', 'photo_buttons'] and 'media_file_id' in session:
                # 发送图片预览
                self.bot.send_photo(
                    message.chat.id,
                    photo=session['media_file_id'],
                    caption=preview_message,
                    parse_mode='HTML',
                    reply_markup=markup
                )
            elif broadcast_type == 'document' and 'media_file_id' in session:
                # 发送文件预览
                self.bot.send_document(
                    message.chat.id,
                    document=session['media_file_id'],
                    caption=preview_message,
                    parse_mode='HTML',
                    reply_markup=markup
                )
            else:
                # 发送文本预览
                self.bot.send_message(
                    message.chat.id,
                    preview_message,
                    parse_mode='HTML',
                    reply_markup=markup
                )
                
        except Exception as e:
            log_message(f"显示广播预览失败: {e}", "ERROR")
            self.bot.reply_to(message, f"❌ 显示预览失败: {e}")

        # 生成广播预览文本
    def generate_broadcast_preview(self, session):
        broadcast_type = session['type']
        preview_parts = []
        
        # 添加内容预览
        if session.get('content'):
            # 转义HTML特殊字符，避免解析错误
            content = session['content'].replace('<', '&lt;').replace('>', '&gt;')
            preview_parts.append(f"<b>内容:</b>\n{content}")
        elif session.get('caption'):
            # 转义HTML特殊字符
            caption = session['caption'].replace('<', '&lt;').replace('>', '&gt;')
            preview_parts.append(f"<b>说明:</b>\n{caption}")
        
        # 添加按钮预览
        if session.get('buttons_config'):
            buttons_text = "<b>按钮:</b>\n"
            for i, (text, url) in enumerate(session['buttons_config'], 1):
                # 转义按钮文本中的HTML字符
                safe_text = text.replace('<', '&lt;').replace('>', '&gt;')
                buttons_text += f"{i}. {safe_text} → {url}\n"
            preview_parts.append(buttons_text)
        
        # 添加媒体类型信息
        if broadcast_type in ['photo', 'photo_buttons']:
            preview_parts.append("📷 <b>包含图片</b>")
        elif broadcast_type == 'document':
            preview_parts.append("📎 <b>包含文件</b>")
        
        return "\n\n".join(preview_parts)

    # 显示广播预览和确认按钮
    def show_broadcast_preview(self, message, session):
        try:
            broadcast_type = session['type']
            preview_text = self.generate_broadcast_preview(session)
            
            # 创建确认键盘
            markup = InlineKeyboardMarkup()
            markup.row(
                InlineKeyboardButton("✅ 确认发送", callback_data="broadcast_confirm"),
                InlineKeyboardButton("❌ 取消发送", callback_data="broadcast_cancel")
            )
            markup.row(
                InlineKeyboardButton("✏️ 重新编辑", callback_data="broadcast_edit")
            )
            
            # 获取用户数量
            try:
                all_users = self.get_all_possible_users()
                total_users = len(all_users)
            except Exception as e:
                log_message(f"获取用户数量失败: {e}", "ERROR")
                total_users = 0
            
            # 发送预览消息 - 使用正确的HTML格式
            preview_message = f"""
<b>📋 广播预览</b>

{preview_text}

<b>发送统计：</b>
• 目标用户数: <code>{total_users}</code>
• 消息类型: <code>{broadcast_type}</code>

请确认是否发送此广播：
"""
            
            # 根据消息类型发送不同的预览
            if broadcast_type in ['photo', 'photo_buttons'] and 'media_file_id' in session:
                # 发送图片预览
                self.bot.send_photo(
                    message.chat.id,
                    photo=session['media_file_id'],
                    caption=preview_message,
                    parse_mode='HTML',
                    reply_markup=markup
                )
            elif broadcast_type == 'document' and 'media_file_id' in session:
                # 发送文件预览
                self.bot.send_document(
                    message.chat.id,
                    document=session['media_file_id'],
                    caption=preview_message,
                    parse_mode='HTML',
                    reply_markup=markup
                )
            else:
                # 发送文本预览
                self.bot.send_message(
                    message.chat.id,
                    preview_message,
                    parse_mode='HTML',
                    reply_markup=markup
                )
                
        except Exception as e:
            log_message(f"显示广播预览失败: {e}", "ERROR")
            # 尝试发送不带HTML的简单消息
            try:
                self.bot.send_message(
                    message.chat.id,
                    "❌ 预览生成失败，请检查广播内容格式",
                    reply_markup=self.create_admin_keyboard()
                )
            except:
                pass
    
    # 清理过期的搜索会话
    def cleanup_old_sessions(self):
        current_time = datetime.datetime.now()
        expired_sessions = []
        
        for search_id, session in self.user_search_sessions.items():
            # 如果会话创建时间超过1小时，则标记为过期
            if (current_time - session['created_time']).total_seconds() > 3600:
                expired_sessions.append(search_id)
        
        for search_id in expired_sessions:
            del self.user_search_sessions[search_id]
        
        if expired_sessions:
            log_message(f"清理了 {len(expired_sessions)} 个过期搜索会话", "CLEANUP")
        
        # 清理过期的频率记录
        cleanup_old_frequency_records()
        # 获取用户广告（VIP用户无广告）

    def get_user_ads(self, user_id, count=2):
        if self.is_vip_user(user_id):
            return []
        
        ads_data = load_advertisements()
        if not ads_data or not ads_data.get("enabled", True):
            return []
        
        enabled_ads = [ad for ad in ads_data.get("ads", []) if ad.get("enabled", True)]
        
        if not enabled_ads:
            return []
        
        # 随机选择广告
        selected_ads = random.sample(enabled_ads, min(count, len(enabled_ads)))
        
        # 更新展示次数
        for ad in selected_ads:
            ad["impressions"] = ad.get("impressions", 0) + 1
        
        save_advertisements(ads_data)
        
        return selected_ads

    # 格式化广告消息
    def format_ads_message(self, ads):
        if not ads:
            return ""
        
        ads_text = "\n━━━━━━━━━━━━━━━━━━━━\n<b>赞助商广告</b>\n"
        
        for i, ad in enumerate(ads, 1):
            ads_text += f"\n{i}. <a href='{ad['url']}'>{ad['text']}</a>"
        
        ads_text += f"\n\n<a href=\"{GO_BUY_URL}\">⭐ 点击我升级VIP可去除广告</a>"
        ads_text += "\n━━━━━━━━━━━━━━━━━━━━"
        
        return ads_text

    # 创建广告管理键盘
    def create_ad_management_keyboard(self):
        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("📋 广告列表", callback_data="ad_list"),
            InlineKeyboardButton("➕ 添加广告", callback_data="ad_add")
        )
        markup.row(
            InlineKeyboardButton("✅ 启用广告", callback_data="ad_enable"),
            InlineKeyboardButton("❌ 禁用广告", callback_data="ad_disable")
        )
        markup.row(
            InlineKeyboardButton("📊 广告统计", callback_data="ad_stats"),
            InlineKeyboardButton("🗑️ 删除广告", callback_data="ad_delete")
        )
        markup.row(InlineKeyboardButton("⬅️ 返回管理员", callback_data="back_to_admin"))
        return markup
    
    # 安全的处理器装饰器
    def safe_handler(self, handler_func):
        def wrapper(message):
            try:
                # 检查请求频率（传入消息内容）
                can_request, reason = check_request_frequency(
                    message.from_user.id, 
                    message.text
                )
                
                if not can_request:
                    # 发送频繁请求警告给管理员
                    user_nickname = get_user_display_name(message.from_user)
                    warning_msg = f"🚨 频繁请求警告\n用户ID: {message.from_user.id}\n昵称: {user_nickname}\n请求内容: {message.text}\n限制原因: {reason}\n时间: {get_current_time()}"
                    
                    # 发送警告给所有管理员
                    for admin_id in self.ADMIN_IDS:
                        try:
                            self.bot.send_message(admin_id, warning_msg)
                        except Exception as e:
                            log_message(f"向管理员 {admin_id} 发送频繁请求警告失败: {e}", "ERROR")
                    
                    log_message(f"用户 {message.from_user.id} 频繁请求被限制，原因: {reason}, 内容: {message.text}", "FREQUENCY_LIMIT")
                    
                    # 根据原因返回不同的提示信息
                    if reason == "相同内容":
                        self.bot.reply_to(message, f"⏳ 相同内容搜索过于频繁，请等待 {BUFFER_TIME} 秒后再试")
                    elif reason == "频繁请求":
                        self.bot.reply_to(message, f"⏳ 请求过于频繁，请等待 {BUFFER_TIME} 秒后再试")
                    else:
                        self.bot.reply_to(message, f"⏳ 系统繁忙，请等待 {BUFFER_TIME} 秒后再试")
                    return
                
                return handler_func(message)
            except Exception as e:
                log_message(f"处理消息时出错 (用户: {message.from_user.id}, 内容: {message.text}): {e}", "ERROR")
                try:
                    self.bot.reply_to(message, "❌ 处理消息时出现错误，请稍后重试")
                except:
                    pass
        return wrapper
    
    # 安全回调处理器装饰器
    def safe_callback_handler(self, handler_func):
        def wrapper(call):
            try:
                # 检查请求频率（传入回调数据）
                can_request, reason = check_request_frequency(
                    call.from_user.id, 
                    call.data
                )
                
                if not can_request:
                    # 发送频繁请求警告给管理员
                    user_nickname = get_user_display_name(call.from_user)
                    warning_msg = f"🚨 频繁请求警告\n用户ID: {call.from_user.id}\n昵称: {user_nickname}\n回调数据: {call.data}\n限制原因: {reason}\n时间: {get_current_time()}"
                    
                    # 发送警告给所有管理员
                    for admin_id in self.ADMIN_IDS:
                        try:
                            self.bot.send_message(admin_id, warning_msg)
                        except Exception as e:
                            log_message(f"向管理员 {admin_id} 发送频繁请求警告失败: {e}", "ERROR")
                    
                    log_message(f"用户 {call.from_user.id} 频繁回调请求被限制，原因: {reason}, 数据: {call.data}", "FREQUENCY_LIMIT")
                    self.bot.answer_callback_query(call.id, f"⏳ 请求过于频繁，请等待 {BUFFER_TIME} 秒")
                    return
                
                return handler_func(call)
            except Exception as e:
                log_message(f"处理回调时出错 (用户: {call.from_user.id}, 数据: {call.data}): {e}", "ERROR")
                try:
                    self.bot.answer_callback_query(call.id, "❌ 操作失败，请重试")
                except:
                    pass
        return wrapper
    
    # 设置消息处理器
    def setup_handlers(self):
        # 处理 /start 命令
        @self.bot.message_handler(commands=["start"])
        @self.safe_handler
        def start(message):
            self.start_(message)
        
        # 处理 /admin 命令
        @self.bot.message_handler(commands=["admin"])
        @self.safe_handler
        def admin(message):
            self.handle_admin_command(message)
        
        # 处理 /my 命令
        @self.bot.message_handler(commands=["my"])
        @self.safe_handler
        def my(message):
            self.show_user_info(message)

        # 处理 /help 命令
        @self.bot.message_handler(commands=["help"])
        @self.safe_handler
        def help(message):
            self.show_help(message)

        # 处理 /random 命令
        @self.bot.message_handler(commands=["random"])
        @self.safe_handler
        def random(message):
            self.handle_random_search(message)

        # 处理"使用协议"关键词
        @self.bot.message_handler(regexp=r"^使用协议$")
        @self.bot.message_handler(commands=["policy"])
        @self.safe_handler
        def ShowUserAgreement(message):
            self.ShowUserAgreement_(message)
        
        # 处理搜索命令
        @self.bot.message_handler(regexp=r'^搜索\s+.+')
        @self.safe_handler
        def handle_search_command(message):
            self.handle_search(message)
        
        # 处理主菜单按钮
        @self.bot.message_handler(func=lambda message: message.text in [
            "📜 使用协议", "ℹ️ 帮助信息", "👤 我的信息", "⭐ VIP服务", "🎲 全库随机", "🔥 热搜榜单"
        ])
        @self.safe_handler
        def handle_main_menu(message):
            if message.text == "📜 使用协议":
                self.ShowUserAgreement_(message)
            elif message.text == "ℹ️ 帮助信息":
                self.show_help(message)
            elif message.text == "👤 我的信息":
                self.show_user_info(message)
            elif message.text == "⭐ VIP服务":
                self.handle_vip_service(message)
            elif message.text == "🎲 全库随机":
                self.handle_random_search(message)
            elif message.text == "🔥 热搜榜单":
                self.handle_hot_searches(message)
        
        # 处理管理员功能按钮
        @self.bot.message_handler(func=lambda message: message.text in [
            "📊 统计信息", "👥 用户管理", "⭐ VIP管理", "📁 日志管理", "🔄 重置限制", 
            "📢 广播消息", "🚫 封禁管理", "🔥 热搜榜单管理", "📤 数据导出", "💬 用户私信", "📢 广告管理", "🏠 返回主菜单"
        ])
        @self.safe_handler
        def handle_admin_buttons(message):
            self.handle_admin_functions(message)
        
        # 处理管理员文本命令
        @self.bot.message_handler(func=lambda message: message.text.startswith(('/vip ', '/unvip ', '/user ', '/log ')))
        @self.safe_handler
        def handle_admin_text(message):
            self.handle_admin_text_commands(message)
        
        # 处理广播消息（图片、文件、文本）
        @self.bot.message_handler(content_types=['text', 'photo', 'document'])
        @self.safe_handler
        def handle_broadcast_content(message):
            # 检查是否有广播会话
            if hasattr(self, 'broadcast_sessions') and message.from_user.id in self.broadcast_sessions:
                self.handle_broadcast_message(message)
            else:
                # 如果没有广播会话，按普通消息处理
                self.handle_search(message)
        
        # 安全检测：监控非管理员用户尝试使用管理员命令
        @self.bot.message_handler(func=lambda message: any(message.text.startswith(cmd) for cmd in ['/vip', '/user', '/log']))
        @self.safe_handler
        def handle_admin_commands_security(message):
            # 检查用户身份，如果是管理员则放行
            if message.from_user.id in self.ADMIN_IDS:
                return  # 管理员正常使用命令，不触发警报
            
            # 获取用户昵称用于识别
            user_nickname = get_user_display_name(message.from_user)
            
            # 构建安全警报消息
            security_alert = f"""
🚨 <b>安全警报 - 管理员命令尝试</b>

🆔 <b>用户ID:</b> <code>{message.from_user.id}</code>
👤 <b>用户昵称:</b> {user_nickname}
📝 <b>尝试命令:</b> <code>{message.text}</code>
⏰ <b>时间:</b> {get_current_time()}

⚠️ <b>警报:</b> 该用户正在尝试使用管理员命令！
"""
            
            # 向所有管理员发送安全警报
            for admin_id in self.ADMIN_IDS:
                try:
                    self.bot.send_message(admin_id, security_alert, parse_mode='HTML')
                    log_message(f"向管理员 {admin_id} 发送安全警报: 用户 {message.from_user.id} 尝试使用命令 {message.text}", "SECURITY")
                except Exception as e:
                    log_message(f"向管理员 {admin_id} 发送安全警报失败: {e}", "ERROR")
            
            # 记录安全事件到日志
            log_message(f"非管理员用户 {message.from_user.id} ({user_nickname}) 尝试使用管理员命令: {message.text}", "SECURITY")
            
            # 给用户回复无权限消息
            self.bot.reply_to(message, "❌ 无权限执行此命令")
        
        # 处理分页回调
        @self.bot.callback_query_handler(func=lambda call: True)
        @self.safe_callback_handler
        def handle_callback(call):
            self.handle_pagination_callback(call)
    
    # 运行机器人主循环
    def run(self):
        # 检查Token是否有效
        if not self.BOT_TOKEN:
            log_message("未找到 TELEGRAM_BOT_TOKEN 环境变量", "ERROR")
            return
        
        restart_count = 0
        consecutive_failures = 0  # 连续失败次数

        while restart_count < MAX_RESTART_COUNT:
            try:
                # 重置连续失败计数
                consecutive_failures = 0
                
                # 创建Telegram机器人实例
                self.bot = telebot.TeleBot(self.BOT_TOKEN)
                log_message(f"🤖 机器人启动成功 (总重启: {restart_count})", "START")
                
                # 设置消息处理器
                self.setup_handlers()
                
                # 开始机器人轮询
                log_message("🔄 机器人开始轮询...", "POLLING")
                
                # 使用更稳定的轮询设置
                self.bot.polling(
                    none_stop=True,
                    timeout=30,
                    long_polling_timeout=30,
                    interval=0.1
                )
                
                # 如果正常返回，记录并立即重启
                log_message("🔄 轮询正常结束，立即重启...", "RESTART")
                restart_count += 1
                
            except KeyboardInterrupt:
                log_message("⏹️ 程序被用户中断", "INFO")
                break
                
            except Exception as e:
                restart_count += 1
                consecutive_failures += 1
                log_message(f"❌ 机器人运行出错: {str(e)[:200]}", "ERROR")
                log_message(f"🔄 立即重启... (第 {restart_count} 次重启，连续失败 {consecutive_failures} 次)", "RESTART")
                
                # 根据连续失败次数调整延迟
                if consecutive_failures > 10:
                    # 如果连续失败10次以上，等待5秒
                    log_message("⚠️ 连续失败过多，等待5秒...", "WARNING")
                    time.sleep(5)
                elif consecutive_failures > 5:
                    # 如果连续失败5次以上，等待2秒
                    time.sleep(2)
                elif consecutive_failures > 3:
                    # 如果连续失败3次以上，等待1秒
                    time.sleep(1)
                else:
                    # 正常情况立即重启
                    time.sleep(0.1)
                
                # 清理资源
                try:
                    if hasattr(self, 'bot'):
                        self.bot = None
                    self.cleanup_old_sessions()
                except:
                    pass
        
        log_message(f"🚨 达到最大重启次数 ({MAX_RESTART_COUNT})，程序退出", "FATAL")

# ------------------ Telegram 机器人主类 - END ------------------ #

# ------------------ MAIN 程序入口点 ------------------ #

if __name__ == "__main__":
    system_restart_count = 0
    
    while system_restart_count < MAX_SYSTEM_RESTARTS:
        try:
            # 确保数据目录存在
            ensure_data_dir()
            ensure_log_dir()
            ensure_temp_dir()
            
            # 创建机器人实例
            bot_instance = TelegramBot()
            
            # 初始化数据库
            bot_instance.initDataBase()
            
            # 启动机器人（内部已包含无限重试）
            bot_instance.run()
            
            # 如果run正常返回，立即重启
            system_restart_count += 1
            log_message(f"🔄 系统级重启... (第 {system_restart_count} 次)", "SYSTEM_RESTART")
            time.sleep(1)
            
        except KeyboardInterrupt:
            log_message("⏹️ 程序被用户中断", "INFO")
            break
        except Exception as e:
            system_restart_count += 1
            log_message(f"🚨 程序启动时发生致命错误: {e}", "FATAL")
            log_message(f"🔄 系统立即重启... (第 {system_restart_count} 次)", "SYSTEM_RESTART")
            time.sleep(1)
    
    log_message(f"💥 达到最大系统重启次数 ({MAX_SYSTEM_RESTARTS})，程序完全退出", "FATAL_EXIT")

# ------------------ MAIN 程序入口点 - END ------------------ #

# END
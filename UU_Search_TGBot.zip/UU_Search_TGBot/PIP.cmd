@echo off

pip install pytelegrambotapi python-dotenv pycryptodome